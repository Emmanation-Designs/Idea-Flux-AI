import { useState, useEffect, useRef } from 'react';
import { ProjectSettingsModal } from './components/ProjectSettingsModal';
import { 
  Plus, 
  History as HistoryIcon, 
  Settings as SettingsIcon, 
  Send, 
  Moon, 
  Sun, 
  Menu, 
  Download, 
  Zap, 
  ChevronRight,
  ChevronDown,
  User,
  AlertCircle,
  ExternalLink,
  Copy,
  ThumbsUp,
  ThumbsDown,
  FileDown,
  MessageSquare,
  Image as ImageIcon,
  Edit2,
  Edit3,
  Trash2,
  Globe,
  Maximize2,
  X,
  Paperclip,
  File as FileIcon,
  Film,
  Video,
  FileText,
  Sparkles,
  Clock,
  Loader2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  ArrowUp,
  HelpCircle,
  Folder,
  FolderKanban,
  FolderPlus,
  Search,
  ArrowLeft,
  AudioLines
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Toaster, toast } from 'sonner';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { clsx, type ClassValue } from 'clsx';
import ModelSelector from './components/ModelSelector';
import { QueueStatusLoader } from './components/QueueStatusLoader';
import { getModel, canUseModel, getDefaultModel } from './ai/modelCatalog';

const supportsLookbehind = (() => {
  try {
    new RegExp('(?<=a)b');
    return true;
  } catch (e) {
    return false;
  }
})();
import { twMerge } from 'tailwind-merge';
import { supabase } from './lib/supabase';
import { applyWatermark } from './utils/watermark';
import { downloadFile, openExternalLink } from './utils/nativeCompat';
import { navigateToVideoStudio } from './utils/videoStudio';
import { playLiveOpenSound } from './utils/liveAudioSounds';

import type { Message, ConversationType, Profile, Project } from './types';
import { projectService } from './lib/projectService';

const safeUUID = (): string => {
  if (typeof window !== 'undefined' && window.crypto && window.crypto.randomUUID) {
    try {
      return window.crypto.randomUUID();
    } catch (e) {}
  }
  return 'msg-' + Math.random().toString(36).substring(2, 15) + '-' + Date.now();
};

const preprocessMath = (content: string): string => {
  if (!content) return "";
  
  // Split by code blocks to avoid replacing math delimiters inside coding regions
  const parts = content.split(/(```[\s\S]*?```)/g);
  
  const processedParts = parts.map((part) => {
    if (part.startsWith('```')) {
      return part;
    }
    
    // Replace block math delimiters \[ ... \] or \\[ ... \\] with $$ ... $$
    let sub = part.replace(/(?:\\{1,2})\[([\s\S]*?)(?:\\{1,2})\]/g, (_, equation) => {
      return `\n$$\n${equation.trim()}\n$$\n`;
    });
    
    // Replace inline math delimiters \( ... \) or \\( ... \\) with $ ... $
    sub = sub.replace(/(?:\\{1,2})\(([\s\S]*?)(?:\\{1,2})\)/g, (_, equation) => {
      return `$${equation.trim()}$`;
    });
    
    return sub;
  });
  
  return processedParts.join('');
};

// --- Components ---
import { Sidebar } from './components/Sidebar';

const ImageWithLoader = ({ src, alt, className, onClick, skipWatermark = false }: { src: string, alt: string, className?: string, onClick?: (e: React.MouseEvent) => void, skipWatermark?: boolean }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [displaySrc, setDisplaySrc] = useState('');

  const getProxyUrl = (url: string) => {
    if (!url) return '';
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return `/api/proxy-image?url=${encodeURIComponent(url)}`;
    }
    return url;
  };

  useEffect(() => {
    let active = true;
    setIsLoaded(false);
    setHasError(false);

    if (src === 'expired') {
      setHasError(true);
      setDisplaySrc('');
      return;
    }
    if (src.startsWith('db:')) {
      const imgId = src.split(':')[1];
      supabase.from('images').select('image_url').eq('id', imgId).single()
        .then(
          ({ data, error }) => {
            if (!active) return;
            if (error || !data?.image_url) {
              console.error("Error fetching lazy image:", error);
              setHasError(true);
            } else {
              const proxiedUrl = getProxyUrl(data.image_url);
              if (skipWatermark) {
                if (active) setDisplaySrc(proxiedUrl);
              } else {
                applyWatermark(proxiedUrl).then(watermarked => {
                  if (active) setDisplaySrc(watermarked);
                });
              }
            }
          },
          () => {
            if (active) setHasError(true);
          }
        );
    } else {
      const proxiedUrl = getProxyUrl(src);
      if (skipWatermark) {
        if (active) setDisplaySrc(proxiedUrl);
      } else {
        applyWatermark(proxiedUrl).then(watermarked => {
          if (active) setDisplaySrc(watermarked);
        });
      }
    }

    return () => {
      active = false;
    };
  }, [src, skipWatermark]);
  
  return (
    <div className={cn("relative overflow-hidden bg-zinc-100 dark:bg-zinc-800 focus-within:ring-2 focus-within:ring-zinc-500", className)} onClick={onClick}>
      {!isLoaded && !hasError && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-zinc-300 dark:border-zinc-600 border-t-zinc-900 dark:border-t-white rounded-full animate-spin" />
        </div>
      )}
      {hasError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
          <ImageIcon className="w-8 h-8 text-zinc-400 mb-2" />
          <p className="text-xs text-zinc-500">Image failed to load</p>
        </div>
      )}
      {displaySrc && (
        <img 
          src={displaySrc} 
          alt={alt} 
          className={cn(
            "w-full h-auto transition-all duration-700 ease-out",
            isLoaded ? "opacity-100 scale-100 blur-0" : "opacity-0 scale-105 blur-lg",
            hasError && "hidden"
          )}
          onLoad={() => setIsLoaded(true)}
          onError={() => setHasError(true)}
          referrerPolicy="no-referrer"
        />
      )}
    </div>
  );
};

import { WelcomeScreen } from './components/WelcomeScreen';
import { ContextForm } from './components/ContextForm';
import { Settings } from './components/Settings';
import { Auth } from './components/Auth';
import { LegalModal } from './components/Legal';
import { CodeBlock } from './components/CodeBlock';
import { DocumentExportCard } from './components/DocumentExportCard';
import { UpgradeModal } from './components/UpgradeModal';
import { AppsView } from './components/AppsView';
import { TextToSpeechView } from './components/TextToSpeechView';
import { VideoStudioView } from './components/VideoStudioView';
import { SupportModal } from './components/SupportModal';
import { LibraryView } from './components/LibraryView';
import { OrganizationProvider } from './context/OrganizationContext';
import { OrganizationSettings } from './components/OrganizationSettings';
import { AcceptInvitationView } from './components/AcceptInvitationView';
import { LiveModeOverlay } from './components/LiveModeOverlay';

const PLAN_LIMITS = {
  free: { messages: Infinity, analysis: Infinity, images: Infinity },
  pro: { messages: Infinity, analysis: Infinity, images: Infinity },
  plus: { messages: Infinity, analysis: Infinity, images: Infinity }
};

// --- Utils ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Main App ---

export default function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 1024);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    return saved ? saved === 'dark' : true;
  });
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [conversations, setConversations] = useState<any[]>([]);
  const [currentConversation, setCurrentConversation] = useState<any | null>(null);
  const hasLoadedInitialConversation = useRef<boolean>(false);
  const liveSessionSavedConvMapRef = useRef<Map<string, string>>(new Map()); // liveSessionId -> conversationId
  const [selectedModelId, setSelectedModelId] = useState<string>(() => {
    return localStorage.getItem('selected_model_default') || 'thinking';
  });
  const [autoMode, setAutoMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('auto_mode_preference');
    return saved !== null ? saved === 'true' : false;
  });
  const [messages, setMessages] = useState<Message[]>([]);
  const [showLiveMode, setShowLiveMode] = useState<boolean>(false);
  const [isTemporaryChat, setIsTemporaryChat] = useState<boolean>(false);
  const [showTempChatIntro, setShowTempChatIntro] = useState<boolean>(false);
  const [input, setInput] = useState('');
  const [activeTag, setActiveTag] = useState<string | null>(null);

  const handleInputChange = (value: string) => {
    let text = value;
    let detectedTag = activeTag;
    
    if (text.startsWith('@Image ')) {
      detectedTag = '@Image';
      text = text.slice('@Image '.length);
    } else if (text.startsWith('@Write ')) {
      detectedTag = '@Write';
      text = text.slice('@Write '.length);
    } else if (text.startsWith('@WebSearch ')) {
      detectedTag = '@WebSearch';
      text = text.slice('@WebSearch '.length);
    } else if (text === '@Image' || text === '@Write' || text === '@WebSearch') {
      detectedTag = text;
      text = '';
    }
    
    setActiveTag(detectedTag);
    setInput(text);
  };
  const [isLoading, setIsLoading] = useState(false);

  const [capacityInfo, setCapacityInfo] = useState<{
    nearingLimit: boolean;
    limitReached: boolean;
    resetTime?: string;
  } | null>(null);

  const [timeRemaining, setTimeRemaining] = useState<number>(0);

  const fetchCapacityStatus = async () => {
    if (!user) return;
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const response = await fetch('/api/subscription/usage', {
        headers: {
          'Authorization': `Bearer ${session?.access_token || ''}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setCapacityInfo({
          nearingLimit: data.nearingLimit,
          limitReached: data.limitReached,
          resetTime: data.usage?.last_capacity_reset || data.usage?.last_daily_reset
        });
        if (data.profile && Object.keys(data.profile).length > 0) {
          setProfile(prev => prev ? { ...prev, ...data.profile } : data.profile);
        }
      }
    } catch (err) {
      console.error("[Capacity Check] Failed to fetch usage/capacity details:", err);
    }
  };

  const formatTimeRemaining = (ms: number) => {
    if (ms <= 0) return "00h 00m 00s";
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours}h ${minutes}m ${seconds}s`;
  };

  // Live countdown timer for the limit reached screen
  useEffect(() => {
    if (!capacityInfo?.limitReached) return;

    const updateTimer = () => {
      const now = new Date();
      // UTC Midnight of next day
      const nextReset = new Date(Date.UTC(
        now.getUTCFullYear(),
        now.getUTCMonth(),
        now.getUTCDate() + 1,
        0, 0, 0, 0
      ));
      const diff = nextReset.getTime() - now.getTime();
      if (diff <= 0) {
        setTimeRemaining(0);
        // Automatically unlock usage on the frontend
        setCapacityInfo(prev => prev ? { ...prev, limitReached: false, nearingLimit: false } : null);
        // Sync fresh status from backend
        fetchCapacityStatus();
      } else {
        setTimeRemaining(diff);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [capacityInfo?.limitReached]);

  // Warning toast when nearing limits
  useEffect(() => {
    if (capacityInfo?.nearingLimit && !capacityInfo?.limitReached) {
      const currentReset = capacityInfo.resetTime || new Date().toISOString().split('T')[0];
      const warnedReset = localStorage.getItem('limit_warning_shown_reset');
      if (warnedReset !== currentReset) {
        toast("You're nearing today's AI usage limit.", {
          description: "Upgrade for higher daily limits or continue when your usage resets.",
          duration: 6000,
          id: "usage-warning",
        });
        localStorage.setItem('limit_warning_shown_reset', currentReset);
      }
    }
  }, [capacityInfo]);

  // Synchronize model preference per user when user or profile is loaded
  useEffect(() => {
    if (user) {
      const saved = localStorage.getItem(`selected_model_${user.id}`);
      if (saved) {
        setSelectedModelId(saved);
      } else {
        const userPlan = profile?.plan || 'free';
        const def = getDefaultModel(userPlan);
        setSelectedModelId(def.id);
      }
    }
  }, [user, profile?.plan]);

  // Handle explicit model selection and save to localStorage
  const handleSelectModel = (modelId: string) => {
    setSelectedModelId(modelId);
    setAutoMode(false);
    localStorage.setItem('auto_mode_preference', 'false');
    if (user) {
      localStorage.setItem(`selected_model_${user.id}`, modelId);
      localStorage.setItem('selected_model_default', modelId);
    }
  };

  const handleToggleAutoMode = (val: boolean) => {
    setAutoMode(val);
    localStorage.setItem('auto_mode_preference', String(val));
  };

  // Prevent users from using premium models if their plan is downgraded or changed
  useEffect(() => {
    const userPlan = profile?.plan || 'free';
    if (selectedModelId && !canUseModel(selectedModelId, userPlan)) {
      const def = getDefaultModel(userPlan);
      setSelectedModelId(def.id);
    }
  }, [profile?.plan, selectedModelId]);
  const [showSettings, setShowSettings] = useState<boolean | 'account' | 'personality' | 'billing' | 'display' | 'legal' | 'support'>(false);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [supportInitialProblem, setSupportInitialProblem] = useState<string>('Video Studio Issue');
  const [showContextForm, setShowContextForm] = useState<ConversationType | null>(null);
  const [showLegal, setShowLegal] = useState<'about' | 'privacy' | 'terms' | null>(null);

  const handleShowLegal = (type: 'about' | 'privacy' | 'terms' | 'support') => {
    if (type === 'support') {
      setShowSettings('support');
      return;
    }
    setShowLegal(type);
    window.history.pushState({}, document.title, `/${type}`);
  };

  const handleCloseLegal = () => {
    setShowLegal(null);
    window.history.pushState({}, document.title, '/');
  };
  const [selectedAttachment, setSelectedAttachment] = useState<{ file: File, preview: string, type: 'image' | 'video' | 'document' | 'other' } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [expandedImage, setExpandedImage] = useState<{url: string, title: string} | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [zoomScale, setZoomScale] = useState(1);
  const [zoomPosition, setZoomPosition] = useState({ x: 0, y: 0 });
  const [isDraggingImage, setIsDraggingImage] = useState(false);
  const dragStartRef = useRef({ x: 0, y: 0 });
  const touchStartDistRef = useRef<number | null>(null);
  const touchStartScaleRef = useRef<number>(1);

  useEffect(() => {
    if (!expandedImage) {
      setZoomScale(1);
      setZoomPosition({ x: 0, y: 0 });
      setIsDraggingImage(false);
    }
  }, [expandedImage]);

  const [streamingMessage, setStreamingMessage] = useState('');
  const [activeView, setActiveView] = useState<'chat' | 'history' | 'apps' | 'images' | 'settings' | 'tts' | 'video' | 'library' | 'project' | 'projects' | 'org-settings'>('chat');
  const [inviteToken, setInviteToken] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get('invite_token') || params.get('token') || null;
    }
    return null;
  });
  const [projectSearchQuery, setProjectSearchQuery] = useState('');
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [isLoadingProjects, setIsLoadingProjects] = useState(false);
  const [showCreateProjectModal, setShowCreateProjectModal] = useState(false);
  const [showProjectSettingsModal, setShowProjectSettingsModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [conversationToMoveId, setConversationToMoveId] = useState<string | null>(null);
  const [moveTargetProjectId, setMoveTargetProjectId] = useState<string | null>('none');
  const [imageSpeed, setImageSpeed] = useState<'fast' | 'quality'>(() => {
    return (localStorage.getItem('image_speed') as 'fast' | 'quality') || 'quality';
  });
  const handleToggleImageSpeed = () => {
    setImageSpeed(prev => {
      const next = prev === 'fast' ? 'quality' : 'fast';
      localStorage.setItem('image_speed', next);
      toast.info(`Visual engine set to ${next === 'fast' ? 'Turbo Speed' : 'HD Quality'}`);
      return next;
    });
  };

  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [currentImagePrompt, setCurrentImagePrompt] = useState('');
  const [timerCount, setTimerCount] = useState(0);
  const [currentStageText, setCurrentStageText] = useState('Initializing Trelvix Visual Engine...');

  // Dynamically resolve absolute URL paths for OpenGraph & Twitter crawler compatibility
  useEffect(() => {
    try {
      const origin = window.location.origin;
      const absoluteLogoUrl = `${origin}/trelvixlogo.png`;
      
      const ogImage = document.querySelector('meta[property="og:image"]');
      if (ogImage) {
        ogImage.setAttribute('content', absoluteLogoUrl);
      }
      
      const twitterImage = document.querySelector('meta[name="twitter:image"]');
      if (twitterImage) {
        twitterImage.setAttribute('content', absoluteLogoUrl);
      }
    } catch (e) {
      console.warn('Failed to dynamically inject direct preview meta path:', e);
    }
  }, []);



  // Timer & stage text controller for ChatGPT-style image generation loading UI
  useEffect(() => {
    let timerId: any = null;
    if (isGeneratingImage && isLoading) {
      setTimerCount(0);
      setCurrentStageText('Initializing Trelvix Visual Engine...');
      
      timerId = setInterval(() => {
        setTimerCount(prev => {
          const next = prev + 1;
          if (next === 2) {
            setCurrentStageText('Parsing composition guidelines...');
          } else if (next === 4) {
            setCurrentStageText('Initializing pixel canvas layout...');
          } else if (next === 8) {
            setCurrentStageText('Synthesizing high-fidelity lighting model...');
          } else if (next === 12) {
            setCurrentStageText('Rendering volumetric details & colors...');
          } else if (next === 16) {
            setCurrentStageText('Finalizing rendering & noise reduction...');
          } else if (next === 22) {
            setCurrentStageText('Applying 8K upscaling filters...');
          }
          return next;
        });
      }, 1000);
    } else {
      setTimerCount(0);
    }

    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [isGeneratingImage, isLoading]);

  // Persist the current active conversation ID to localStorage to survive page reloads gracefully
  useEffect(() => {
    if (currentConversation?.id) {
      localStorage.setItem('last_conversation_id', currentConversation.id);
    } else {
      localStorage.removeItem('last_conversation_id');
    }
  }, [currentConversation?.id]);

  // Refs to track state during location changes and avoid stale closure / dependency loops
  const conversationsRef = useRef(conversations);
  useEffect(() => {
    conversationsRef.current = conversations;
  }, [conversations]);

  const currentConversationRef = useRef(currentConversation);
  useEffect(() => {
    currentConversationRef.current = currentConversation;
  }, [currentConversation]);

  // Handle browser Back/Forward navigation & initial route matching
  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname;
      const cleanPath = path.toLowerCase().replace(/\/$/, "");
      
      if (cleanPath === '/privacy') {
        setShowLegal('privacy');
        setShowSettings(false);
      } else if (cleanPath === '/terms') {
        setShowLegal('terms');
        setShowSettings(false);
      } else if (cleanPath === '/about') {
        setShowLegal('about');
        setShowSettings(false);
      } else if (cleanPath === '/support') {
        setShowSettings('support');
        setShowLegal(null);
      } else if (cleanPath === '/video' || cleanPath === '/videostudio' || cleanPath === '/video-studio') {
        navigateToVideoStudio();
        setShowSettings(false);
        setShowLegal(null);
      } else if (cleanPath === '/billing') {
        setShowSettings('billing');
        setShowLegal(null);
      } else if (cleanPath === '/settings') {
        setShowSettings('account');
        setShowLegal(null);
      } else if (cleanPath.startsWith('/settings/')) {
        const subSection = cleanPath.split('/settings/')[1];
        if (['account', 'profile', 'personality', 'billing', 'display', 'support', 'legal'].includes(subSection)) {
          const sectionKey = subSection === 'profile' ? 'account' : subSection as any;
          setShowSettings(sectionKey);
          setShowLegal(null);
        } else {
          setShowSettings('account');
          setShowLegal(null);
        }
      } else {
        setShowLegal(null);
        setShowSettings(false);
        
        const projListMatch = path.match(/^\/(projects|workspaces)/i);
        const projWithConvMatch = path.match(/^\/project\/([a-f0-9-]+)\/c\/([a-f0-9-]+)/i);
        const projOnlyMatch = path.match(/^\/project\/([a-f0-9-]+)/i);
        const cMatch = path.match(/^\/c\/([a-f0-9-]+)/i);

        const currentConvs = conversationsRef.current;
        const curConv = currentConversationRef.current;

        if (projListMatch) {
          setActiveView('projects');
        } else if (projWithConvMatch) {
          const projId = projWithConvMatch[1];
          const urlId = projWithConvMatch[2];
          setSelectedProjectId(projId);
          const found = currentConvs.find(c => c.id === urlId);
          if (found && curConv?.id !== urlId) {
            setCurrentConversation(found);
            const uniqueMessages = (found.messages || []).reduce((acc: any[], curr: any, idx: number) => {
              const messageId = curr.id || `msg-legacy-${idx}`;
              if (!acc.find(m => m.id === messageId)) {
                acc.push({ ...curr, id: messageId });
              }
              return acc;
            }, []);
            setMessages(uniqueMessages);
            setStreamingMessage('');
            setActiveView('chat');
          }
        } else if (projOnlyMatch) {
          const projId = projOnlyMatch[1];
          setSelectedProjectId(projId);
          if (curConv !== null) {
            setCurrentConversation(null);
            setMessages([]);
          }
          setActiveView('project');
        } else if (cMatch) {
          const urlId = cMatch[1];
          const found = currentConvs.find(c => c.id === urlId);
          if (found && curConv?.id !== urlId) {
            setCurrentConversation(found);
            setSelectedProjectId(found.project_id || null);
            const uniqueMessages = (found.messages || []).reduce((acc: any[], curr: any, idx: number) => {
              const messageId = curr.id || `msg-legacy-${idx}`;
              if (!acc.find(m => m.id === messageId)) {
                acc.push({ ...curr, id: messageId });
              }
              return acc;
            }, []);
            setMessages(uniqueMessages);
            setStreamingMessage('');
            setActiveView('chat');
          }
        } else if (path === '/' || path === '') {
          if (curConv !== null) {
            setCurrentConversation(null);
            setMessages([]);
            setSelectedProjectId(null);
            setActiveView('chat');
          }
        }
      }
    };

    handleLocationChange();

    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  // Synchronize browser URL with the active view and conversation ID
  useEffect(() => {
    let expectedPath = '/';
    if (showLegal) {
      expectedPath = `/${showLegal}`;
    } else if (showSettings) {
      if (showSettings === 'support') {
        expectedPath = '/support';
      } else if (typeof showSettings === 'string') {
        expectedPath = `/settings/${showSettings}`;
      } else {
        expectedPath = '/settings';
      }
    } else if (activeView === 'projects') {
      expectedPath = '/projects';
    } else if (activeView === 'project' && selectedProjectId && !currentConversation?.id) {
      expectedPath = `/project/${selectedProjectId}`;
    } else if (currentConversation?.id) {
      expectedPath = selectedProjectId 
        ? `/project/${selectedProjectId}/c/${currentConversation.id}` 
        : `/c/${currentConversation.id}`;
    } else if (activeView === 'chat' && !selectedProjectId) {
      expectedPath = '/';
    } else {
      return;
    }

    if (window.location.pathname !== expectedPath) {
      if (window.location.pathname === '/' || window.location.pathname === '') {
        window.history.replaceState({ conversationId: currentConversation?.id || null }, document.title, expectedPath);
      } else {
        window.history.pushState({ conversationId: currentConversation?.id || null }, document.title, expectedPath);
      }
    }
  }, [currentConversation?.id, activeView, selectedProjectId, showLegal, showSettings]);

  // Tab-Focus recovery & Background Sync:
  // If the user leaves the tab and comes back, and we were generating an image or loading,
  // sync the conversation from the database instantly to fetch any completed output from the background!
  useEffect(() => {
    const handleVisibilitySync = async () => {
      if (document.visibilityState === 'visible' && user && currentConversation?.id) {
        console.log('[VisibilitySync] Tab focused. Refreshing current conversation state to sync background progress...');
        try {
          const { data, error } = await supabase
            .from('conversations')
            .select('*')
            .eq('id', currentConversation.id)
            .single();

          if (error) {
            console.warn('[VisibilitySync] Could not pull current conversation snapshot:', error);
            return;
          }

          if (data) {
            // Update the sidebar conversations list
            setConversations(prev => prev.map(c => c.id === data.id ? data : c));
            
            // Re-sync messages
            const uniqueMessages = (data.messages || []).reduce((acc: any[], curr: any, idx: number) => {
              const messageId = curr.id || `msg-legacy-${idx}`;
              if (!acc.find(m => m.id === messageId)) {
                acc.push({ ...curr, id: messageId });
              }
              return acc;
            }, []);

            // Check if been updated (e.g. image has been saved by server)
            const hasNewImage = uniqueMessages.some((m: any) => m.role === 'assistant' && m.image_url && !messages.find((oldM: any) => oldM.id === m.id));
            if (hasNewImage || isGeneratingImage) {
              console.log('[VisibilitySync] Found new synchronized background data. Updating active UI state...');
              setMessages(uniqueMessages);
              setCurrentConversation(data);
              
              if (isGeneratingImage && uniqueMessages.some((m: any) => m.role === 'assistant' && m.image_url)) {
                setIsGeneratingImage(false);
                setIsLoading(false);
              }
            }
          }
        } catch (syncErr) {
          console.error('[VisibilitySync] Background synchronization routine failed:', syncErr);
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilitySync);
    window.addEventListener('focus', handleVisibilitySync);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilitySync);
      window.removeEventListener('focus', handleVisibilitySync);
    };
  }, [user, currentConversation?.id, messages, isGeneratingImage]);
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [upgradeReason, setUpgradeReason] = useState<'usage' | 'images' | 'manual'>('usage');
  const [hasError, setHasError] = useState(false);
  const [lastFailedRequest, setLastFailedRequest] = useState<{content: string, conv?: any} | null>(null);
  const [viewportHeight, setViewportHeight] = useState<string>('100%');
  const [loadedRemarkGfm, setLoadedRemarkGfm] = useState<any>(null);

  // Screen Wake Lock controller to prevent mobile screen sleep during model generation
  const wakeLockRef = useRef<any>(null);
  const shouldKeepAwake = isLoading || isGeneratingImage;

  useEffect(() => {
    const acquireLock = async () => {
      if (shouldKeepAwake && 'wakeLock' in navigator) {
        try {
          // Check if already active
          if (!wakeLockRef.current) {
            wakeLockRef.current = await (navigator.wakeLock as any).request('screen');
            console.log('[WakeLock] Screen Wake Lock acquired successfully (active state)');
          }
        } catch (err) {
          console.warn('[WakeLock] Screen Wake Lock acquisition failed:', err);
        }
      }
    };

    const releaseLock = async () => {
      if (wakeLockRef.current) {
        try {
          await wakeLockRef.current.release();
          console.log('[WakeLock] Screen Wake Lock released');
        } catch (err) {
          console.error('[WakeLock] Error releasing Wake Lock:', err);
        }
        wakeLockRef.current = null;
      }
    };

    if (shouldKeepAwake) {
      acquireLock();
    } else {
      releaseLock();
    }

    const handleVisibilityChange = async () => {
      if (shouldKeepAwake && document.visibilityState === 'visible' && 'wakeLock' in navigator) {
        try {
          wakeLockRef.current = await (navigator.wakeLock as any).request('screen');
          console.log('[WakeLock] Screen Wake Lock re-acquired on visibility change');
        } catch (err) {
          console.warn('[WakeLock] Re-acquisition failed:', err);
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      releaseLock();
    };
  }, [shouldKeepAwake]);

  useEffect(() => {
    if (supportsLookbehind) {
      import('remark-gfm').then((mod) => {
        setLoadedRemarkGfm(() => mod.default);
      }).catch((e) => {
        console.warn("[Markdown] Dynamic load of remark-gfm failed:", e);
      });
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    const updateHeight = () => {
      if (window.visualViewport) {
        setViewportHeight(`${window.visualViewport.height}px`);
      } else {
        setViewportHeight('100%');
      }
    };

    updateHeight();
    
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', updateHeight);
      window.visualViewport.addEventListener('scroll', updateHeight);
    }
    window.addEventListener('resize', updateHeight);

    return () => {
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', updateHeight);
        window.visualViewport.removeEventListener('scroll', updateHeight);
      }
      window.removeEventListener('resize', updateHeight);
    };
  }, []);
  const loadingIntervalRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (isLoading) {
      if (loadingIntervalRef.current) clearInterval(loadingIntervalRef.current);
    } else {
      if (loadingIntervalRef.current) clearInterval(loadingIntervalRef.current);
    }
    return () => {
      if (loadingIntervalRef.current) clearInterval(loadingIntervalRef.current);
    };
  }, [isLoading]);

  // Quiet background synchronization / session recovery effect
  useEffect(() => {
    let active = true;
    let timerId: any = null;
    
    const checkConversationHistory = async () => {
      if (!currentConversation?.id) return;
      
      // Only check if the last local state message is from 'user' and the UI is NOT actively streaming
      if (messages.length > 0 && messages[messages.length - 1].role === 'user' && !streamingMessage) {
        try {
          console.log("[Auto-Sync] Checking if server background worker completed reply...");
          const { data, error } = await supabase
            .from('conversations')
            .select('messages')
            .eq('id', currentConversation.id)
            .single();
            
          if (error) {
            console.error("[Auto-Sync] Error checking:", error);
            return;
          }
          
          if (data && data.messages && data.messages.length > messages.length) {
            const lastMsg = data.messages[data.messages.length - 1];
            if (lastMsg.role === 'assistant') {
              console.log("[Auto-Sync] Found background reply! Healing conversation locally.");
              
              // Filter out duplicates and stabilize
              const uniqueMessages = (data.messages || []).reduce((acc: any[], curr: any, idx: number) => {
                const messageId = curr.id || `msg-legacy-${idx}`;
                if (!acc.find(m => m.id === messageId)) {
                  acc.push({ ...curr, id: messageId });
                }
                return acc;
              }, []);
              
              if (active) {
                setMessages(uniqueMessages);
                setConversations(prev => prev.map(c => c.id === currentConversation.id ? { ...c, messages: uniqueMessages, updated_at: new Date().toISOString() } : c));
                setCurrentConversation(prev => prev ? { ...prev, messages: uniqueMessages } : null);
                setHasError(false);
              }
              return; 
            }
          }
        } catch (err) {
          console.error("[Auto-Sync] Check exception:", err);
        }
      }
    };

    checkConversationHistory();

    if (messages.length > 0 && messages[messages.length - 1].role === 'user' && !streamingMessage) {
      timerId = setInterval(() => {
        checkConversationHistory();
      }, 4000);
    }

    return () => {
      active = false;
      if (timerId) clearInterval(timerId);
    };
  }, [currentConversation?.id, messages, streamingMessage]);

  // Self-healing startup & reload state resume logic
  useEffect(() => {
    if (messages.length > 0 && messages[messages.length - 1].role === 'user') {
      const lastMsg = messages[messages.length - 1];
      const lowerContent = (lastMsg.content || '').toLowerCase();
      const docFilter = /\b(pdf|docx|xlsx|word|excel|spreadsheet|csv|document|resume|report|cv|curriculum\s*vitae|invoice|presentation|budget|letter|email|cover\s*letter|essay|article|post|text|contract|agreement|outline|syllabus|proposal|workbook|chart|table|schema|blueprint|database)\b/i;
      const isImg = (currentConversation?.type === 'image' || 
        ((/generate|create|make|draw|design|show me|give me|i want|produce|paint|illustrate|visualize|render/i.test(lowerContent)) && 
         (/image|picture|photo|logo|flyer|poster|illustration|drawing|sketch|graphic|art|realistic|scene|portrait|landscape/i.test(lowerContent))) ||
        /\b(logo|flyer|poster|art|sketch|drawing)\b/i.test(lowerContent) ||
        /image of|picture of|photo of|generate an image|create an image|make an image|generate a picture|create a picture/i.test(lowerContent) ||
        /^realistic |^photorealistic /i.test(lowerContent)) && 
        !docFilter.test(lowerContent);
        
      setIsLoading(true);
      if (isImg) {
        setIsGeneratingImage(true);
        setCurrentImagePrompt(lastMsg.content || '');
      } else {
        setIsGeneratingImage(false);
        setCurrentImagePrompt('');
      }
    } else {
      setIsLoading(false);
      setIsGeneratingImage(false);
    }
  }, [currentConversation?.id, messages.length]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const generationAbortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  useEffect(() => {
    // Auth Listener
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      fetchProfile();
      fetchConversations();
      fetchCapacityStatus();
      fetchProjects();
    } else {
      setProfile(null);
      setConversations([]);
      setCurrentConversation(null);
      setMessages([]);
      setCapacityInfo(null);
    }
  }, [user]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      document.documentElement.style.colorScheme = 'dark';
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.style.colorScheme = 'light';
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  useEffect(() => {
    scrollToBottom();
  }, [messages, streamingMessage]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!user) return;
    
    // Explicit whitelist of user-editable non-privileged profile columns.
    // Privileged fields like is_admin, role, plan, current_plan, subscription fields,
    // and usage counters must NEVER be updated directly from the client.
    const ALLOWED_CLIENT_PROFILE_KEYS = [
      'name', 
      'avatar_url',
      'personality',
      'billing_email',
      'billing_country',
      'billing_currency',
      'country_code',
      'memory_enabled'
    ];

    const FORBIDDEN_PRIVILEGED_KEYS = new Set([
      'is_admin',
      'role',
      'plan',
      'current_plan',
      'subscription_tier',
      'subscription_expires_at',
      'subscription_status',
      'subscription_provider',
      'subscription_start',
      'subscription_end',
      'billing_cycle',
      'stripe_customer_id',
      'paypal_subscription_id',
      'lemon_squeezy_subscription_id',
      'messages_used_today',
      'analysis_used_today',
      'images_used_today',
      'last_usage_reset',
      'tts_characters_used',
      'tts_reset_date',
      'daily_ai_capacity_used',
      'last_capacity_reset',
      'last_daily_reset',
      'last_monthly_reset',
      'tts_characters_used_monthly',
      'rewarded_bonus'
    ]);
    
    const filteredUpdates: any = {};
    Object.keys(updates).forEach(key => {
      if (ALLOWED_CLIENT_PROFILE_KEYS.includes(key) && !FORBIDDEN_PRIVILEGED_KEYS.has(key)) {
        filteredUpdates[key] = (updates as any)[key];
      }
    });

    if (Object.keys(filteredUpdates).length === 0) {
      // If only privileged or non-client-editable fields were provided (e.g. from subscription sync),
      // re-fetch the authoritative server-stored profile without performing an untrusted client write.
      if (user) {
        await fetchProfile();
      }
      return profile;
    }

    try {
      const { data, error } = await supabase
        .from('profiles')
        .update(filteredUpdates)
        .eq('id', user.id)
        .select()
        .single();

      if (error) throw error;
      if (data) {
        setProfile(prev => ({
          ...prev,
          ...data,
          email: user.email,
          billing_email: data.billing_email || user.email
        }));
      }
      return data;
    } catch (error) {
      console.error("Error updating profile:", error);
      // Don't toast here as it might be a background update, but do throw for callers who care
      throw error;
    }
  };

  const fetchProfile = async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();
    
    const now = new Date();
    
    if (error && error.code === 'PGRST116') {
      // Create profile if not exists
      // Secure creation: strictly assign free plan, user role, no admin, 0 counters
      const newProfile = {
        id: user.id,
        name: typeof user.user_metadata?.full_name === 'string' ? user.user_metadata.full_name.slice(0, 100) : null,
        avatar_url: typeof user.user_metadata?.avatar_url === 'string' ? user.user_metadata.avatar_url : null,
        personality: 'creative',
        billing_email: user.email || null,
        plan: 'free',
        current_plan: 'free',
        is_admin: false,
        role: 'user',
        messages_used_today: 0,
        analysis_used_today: 0,
        images_used_today: 0,
        last_usage_reset: now.toISOString(),
        subscription_expires_at: null,
        subscription_status: 'active'
      };
      const { data: created, error: insertErr } = await supabase.from('profiles').insert(newProfile).select().single();
      if (insertErr) {
        console.error("Failed to insert initial profile:", insertErr);
      }
      setProfile(created ? { ...created, email: user.email, billing_email: created.billing_email || user.email } : null);
    } else if (data) {
      const profileWithEmail = {
        ...data,
        email: user.email,
        billing_email: data.billing_email || user.email
      };
      setProfile(profileWithEmail);
    }
  };

  const fetchConversations = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('conversations')
        .select('*')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });

      if (error) throw error;
      
      // Filter out duplicates by ID, filter out temporary chats, and ensure every conversation has an ID
      const uniqueConversations = (data || [])
        .filter((c: any) => !c.is_temporary)
        .reduce((acc: any[], curr: any) => {
          if (curr.id && !acc.find(c => c.id === curr.id)) {
            acc.push(curr);
          }
          return acc;
        }, []);
      
      setConversations(uniqueConversations);

      // Startup URL parsing and restoration / redirect
      const path = window.location.pathname;
      const projWithConvMatch = path.match(/^\/project\/([a-f0-9-]+)\/c\/([a-f0-9-]+)/i);
      const cMatch = path.match(/^\/c\/([a-f0-9-]+)/i);
      const urlId = projWithConvMatch ? projWithConvMatch[2] : (cMatch ? cMatch[1] : null);
      const projId = projWithConvMatch ? projWithConvMatch[1] : null;

      if (urlId) {
        // Deep link: load conversation from URL
        const urlConv = uniqueConversations.find((c: any) => c.id === urlId);
        if (urlConv) {
          console.log("[Chat] Auto-restoring conversation from deep link:", urlId);
          setCurrentConversation(urlConv);
          setSelectedProjectId(projId || urlConv.project_id || null);
          
          const uniqueMessages = (urlConv.messages || []).reduce((acc: any[], curr: any, idx: number) => {
            const messageId = curr.id || `msg-legacy-${idx}`;
            if (!acc.find(m => m.id === messageId)) {
              acc.push({ ...curr, id: messageId });
            }
            return acc;
          }, []);
          
          setMessages(uniqueMessages);
          setStreamingMessage('');
          setActiveView('chat');
        } else {
          console.warn("[Chat] Conversation from deep link not found or unauthorized:", urlId);
          setCurrentConversation(null);
          setMessages([]);
        }
      } else if (path === '/' || path === '') {
        // Root visit: always open a clean new chat screen on initial launch
        if (!hasLoadedInitialConversation.current) {
          console.log("[Chat] Root visit: starting on clean new chat screen");
          setCurrentConversation(null);
          setMessages([]);
          setStreamingMessage('');
          setActiveView('chat');
        }
      }
      hasLoadedInitialConversation.current = true;

      // Auto-migrate/heal expiring images in the background after the UI starts rendering to keep chat loading incredibly fast
      setTimeout(() => {
        uniqueConversations.forEach(async (conv: any) => {
          const messages = conv.messages || [];
          let updated = false;
          const newMessages = await Promise.all(messages.map(async (m: any) => {
            if (m.image_url && !m.image_url.startsWith('db:') && !m.image_url.startsWith('data:') && m.image_url !== 'expired') {
              try {
                const proxyResp = await fetch('/api/proxy-image', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ url: m.image_url })
                });
                if (proxyResp.ok) {
                  const blob = await proxyResp.blob();
                  const reader = new FileReader();
                  const base64 = await new Promise<string>((resolve) => {
                    reader.onloadend = () => resolve(reader.result as string);
                    reader.readAsDataURL(blob);
                  });
                  
                  const { data: imgData } = await supabase.from('images').insert({
                    user_id: user.id,
                    prompt: m.content || "Migrated Image",
                    image_url: base64
                  }).select().single();
                  
                  if (imgData) {
                    updated = true;
                    return { ...m, image_url: `db:${imgData.id}` };
                  }
                } else {
                  // If it fails to fetch (e.g. 403, 404, or 500 because of an expired OpenAI URL),
                  // mark it as 'expired' so we do not attempt to proxy it again on subsequent reloads.
                  console.warn(`[Auto-Migrate] Found expired image url, marking as expired: ${m.image_url.substring(0, 100)}`);
                  updated = true;
                  return { ...m, image_url: 'expired' };
                }
              } catch (e) {
                console.error("Migration failed:", e);
              }
            }
            return m;
          }));

          if (updated) {
            await updateConversationMessages(conv.id, newMessages);
            setConversations(prev => prev.map(c => c.id === conv.id ? { ...c, messages: newMessages } : c));
            setCurrentConversation(prev => (prev && prev.id === conv.id) ? { ...prev, messages: newMessages } : prev);
          }
        });
      }, 1000);
    } catch (error) {
      console.error("Error fetching history:", error);
    }
  };

  const fetchProjects = async () => {
    if (!user) return;
    setIsLoadingProjects(true);
    try {
      let list = await projectService.listProjects(user.id);
      
      // Seed default projects if none exist
      if (list.length === 0) {
        console.log('[Projects] Seeding default projects for new user:', user.id);
        const defaults = [
          { title: 'Website', description: 'Website development & engineering workspace', icon: 'Globe', color: 'emerald' },
          { title: 'Business', description: 'Business plans, strategy & operations', icon: 'Briefcase', color: 'blue' },
          { title: 'School', description: 'Academic research, studies & learning', icon: 'GraduationCap', color: 'purple' },
          { title: 'Personal', description: 'Personal ideas, organization & thoughts', icon: 'User', color: 'pink' }
        ];
        
        const seededList = [];
        for (const p of defaults) {
          try {
            const created = await projectService.createProject(user.id, p.title, p.description, p.icon, p.color);
            seededList.push(created);
          } catch (err) {
            console.error('[Projects] Error seeding default project:', p.title, err);
          }
        }
        
        if (seededList.length > 0) {
          list = seededList;
        } else {
          list = await projectService.listProjects(user.id);
        }
      }
      
      setProjects(list);
    } catch (err) {
      console.error('[Projects] Error fetching projects:', err);
    } finally {
      setIsLoadingProjects(false);
    }
  };

  const handleCreateProject = async () => {
    if (!user || !newProjectName.trim()) return;
    try {
      const created = await projectService.createProject(user.id, newProjectName.trim(), newProjectDesc.trim());
      setProjects(prev => [created, ...prev]);
      setShowCreateProjectModal(false);
      setNewProjectName('');
      setNewProjectDesc('');
      toast.success('Project created successfully!');
      // Automatically switch to the newly created project page!
      setSelectedProjectId(created.id);
      setActiveView('project');
    } catch (err) {
      toast.error('Failed to create project');
    }
  };

  const handleRenameProject = async (projectId: string, newTitle: string) => {
    try {
      const updated = await projectService.renameProject(projectId, newTitle);
      setProjects(prev => prev.map(p => p.id === projectId ? updated : p));
      toast.success('Project renamed successfully');
    } catch (err) {
      toast.error('Failed to rename project');
    }
  };

  const handleUpdateProjectSettings = async (updates: { title: string; description: string; color: string; icon: string }) => {
    if (!selectedProjectId) return;
    try {
      const updated = await projectService.updateProject(selectedProjectId, updates);
      setProjects(prev => prev.map(p => p.id === selectedProjectId ? updated : p));
      toast.success('Project details updated successfully');
    } catch (err) {
      toast.error('Failed to update project settings');
      throw err;
    }
  };

  const handleDeleteProject = async (projectId: string) => {
    const confirm = window.confirm('Are you sure you want to delete this project? All conversations inside this project will be moved to your Personal Workspace.');
    if (!confirm) return;
    try {
      setConversations(prev => prev.map(c => c.project_id === projectId ? { ...c, project_id: null } : c));
      if (currentConversation && currentConversation.project_id === projectId) {
        setCurrentConversation(prev => prev ? { ...prev, project_id: null } : null);
      }
      await supabase.from('conversations').update({ project_id: null }).eq('project_id', projectId);
      await projectService.deleteProject(projectId);
      setProjects(prev => prev.filter(p => p.id !== projectId));
      setSelectedProjectId(null);
      setActiveView('chat');
      toast.success('Project deleted. Conversations moved to Personal Workspace.');
    } catch (err) {
      console.error('[DeleteProject] Error:', err);
      toast.error('Failed to delete project');
    }
  };

  const handleMoveConversation = async () => {
    if (!conversationToMoveId) return;
    const targetProjId = moveTargetProjectId === 'none' ? null : moveTargetProjectId;
    try {
      if (targetProjId) {
        await projectService.moveConversationIntoProject(conversationToMoveId, targetProjId);
      } else {
        await projectService.removeConversationFromProject(conversationToMoveId);
      }
      setConversations(prev => prev.map(c => c.id === conversationToMoveId ? { ...c, project_id: targetProjId } : c));
      if (currentConversation && currentConversation.id === conversationToMoveId) {
        setCurrentConversation(prev => prev ? { ...prev, project_id: targetProjId } : null);
      }
      toast.success(targetProjId ? 'Conversation moved to project' : 'Conversation moved to personal workspace');
      setConversationToMoveId(null);
    } catch (err) {
      toast.error('Failed to move conversation');
    }
  };

  const handleRemoveFromProject = async (conversationId: string) => {
    try {
      await projectService.removeConversationFromProject(conversationId);
      setConversations(prev => prev.map(c => c.id === conversationId ? { ...c, project_id: null } : c));
      if (currentConversation && currentConversation.id === conversationId) {
        setCurrentConversation(prev => prev ? { ...prev, project_id: null } : null);
      }
      toast.success('Conversation removed from project');
    } catch (err) {
      toast.error('Failed to remove conversation from project');
    }
  };

  const handleNewChat = () => {
    setCurrentConversation(null);
    setMessages([]);
    setStreamingMessage('');
    setActiveView('chat');
    if (window.innerWidth < 1024) setIsSidebarOpen(false);
  };

  const updateConversationMessages = async (id: string, newMessages: Message[]) => {
    try {
      const { error } = await supabase
        .from('conversations')
        .update({ 
          messages: newMessages, 
          updated_at: new Date().toISOString() 
        })
        .eq('id', id);
      
      if (error) throw error;
      return true;
    } catch (err) {
      console.error("[Chat] Failed to update history:", err);
      // We don't toast error here to avoid interrupting the flow, 
      // but the log will help debugging.
      return false;
    }
  };

  const handleSelectConversation = (id: string) => {
    const conv = conversations.find(c => c.id === id);
    if (conv) {
      setCurrentConversation(conv);
      setIsTemporaryChat(!!conv.is_temporary);
      setSelectedProjectId(conv.project_id || null);
      
      // Filter out duplicate messages by ID and ensure every message has a unique ID
      const uniqueMessages = (conv.messages || []).reduce((acc: any[], curr: any, idx: number) => {
        const messageId = curr.id || `msg-legacy-${idx}`;
        if (!acc.find(m => m.id === messageId)) {
          acc.push({ ...curr, id: messageId });
        }
        return acc;
      }, []);
      
      setMessages(uniqueMessages);
      setStreamingMessage('');
      setActiveView('chat');
      if (window.innerWidth < 1024) setIsSidebarOpen(false);
    }
  };

  const handleDeleteConversation = (id: string) => {
    setDeleteConfirmId(id);
  };

  const confirmDeleteConversation = async () => {
    if (!deleteConfirmId) return;
    const id = deleteConfirmId;
    setDeleteConfirmId(null);
    try {
      const { error } = await supabase.from('conversations').delete().eq('id', id);
      if (error) throw error;
      setConversations(prev => prev.filter(c => c.id !== id));
      if (currentConversation?.id === id) {
        handleNewChat();
      }
      toast.success('Conversation deleted');
    } catch (err) {
      console.error("Error deleting conversation:", err);
      toast.error('Failed to delete conversation');
    }
  };

  const handleContextSubmit = async (data: any) => {
    const type = showContextForm!;
    setShowContextForm(null);
    
    let prompt = "";
    let title = "";

    if (type === 'idea') {
      prompt = `Generate 5 viral content ideas for ${data.topic} on ${data.platform} with a ${data.tone} tone.`;
      title = `${data.topic} Ideas`;
    } else if (type === 'script') {
      prompt = `Write a ${data.length} script for ${data.platform} about ${data.topic}.`;
      title = `${data.topic} Script`;
    } else if (type === 'hashtag') {
      prompt = `Generate ${data.count || 15} trending hashtags for ${data.topic} on ${data.platform}.`;
      title = `${data.topic} Hashtags`;
    } else if (type === 'image') {
      prompt = `Generate a ${data.style} image of: ${data.prompt}`;
      title = `${data.prompt.slice(0, 20)}... Image`;
    }

    await startConversation(type, title, prompt, data);
  };

  const conversationLockRef = useRef<Promise<any> | null>(null);

  const startConversation = async (
    type: ConversationType, 
    title: string, 
    initialPrompt: string, 
    metadata: any = {}, 
    shouldClearMessages = true
  ) => {
    if (!user) return null;

    // Guard to avoid duplicate conversation creation in React StrictMode
    if (conversationLockRef.current) {
      console.log("[Chat] Deduplicating dynamic startConversation call...");
      return conversationLockRef.current;
    }

    const isTemp = isTemporaryChat;
    const newConversation: any = {
      user_id: user.id,
      title: title || (isTemp ? 'Temporary Chat' : 'New Chat'),
      type: type,
      messages: [],
      metadata: metadata,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      project_id: selectedProjectId || null
    };

    const creationPromise = (async () => {
      setIsLoading(true);
      try {
        let data = null;
        let error = null;

        if (isTemp) {
          const { data: tempRes, error: tempErr } = await supabase
            .from('conversations')
            .insert({ ...newConversation, is_temporary: true })
            .select()
            .single();

          if (tempErr && tempErr.message && tempErr.message.includes('is_temporary')) {
            console.warn("[Chat] Database lacks is_temporary column, retrying fallback insert...");
            const { data: fallbackRes, error: fallbackErr } = await supabase
              .from('conversations')
              .insert(newConversation)
              .select()
              .single();
            data = fallbackRes;
            error = fallbackErr;
          } else {
            data = tempRes;
            error = tempErr;
          }
        } else {
          const { data: normalRes, error: normalErr } = await supabase
            .from('conversations')
            .insert(newConversation)
            .select()
            .single();
          data = normalRes;
          error = normalErr;
        }

        if (error) {
          console.error("Supabase insert error:", error);
          toast.error(`Failed to create conversation history`);
          setIsLoading(false);
          return null;
        }

        console.log("[Chat] Conversation created:", data.id);
        setCurrentConversation(data);
        setConversations(prev => {
          if (isTemp || data.is_temporary) return prev; // Do NOT add temporary conversations to the sidebar history list!
          if (prev.some(c => c.id === data.id)) return prev;
          return [data, ...prev];
        });
        if (shouldClearMessages) {
          setMessages([]); // Ensure messages are cleared for new chat
        }
        
        return data;
      } catch (err) {
        console.error("Error in startConversation:", err);
        setIsLoading(false);
        return null;
      } finally {
        // Clear active lock after a thin grace period so future chats can trigger smoothly
        setTimeout(() => {
          conversationLockRef.current = null;
        }, 1000);
      }
    })();

    conversationLockRef.current = creationPromise;
    return creationPromise;
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 20 * 1024 * 1024) { // 20MB limit
        toast.error('File too large. Please select a file under 20MB');
        return;
      }

      let type: 'image' | 'video' | 'document' | 'other' = 'other';
      if (file.type.startsWith('image/')) type = 'image';
      else if (file.type.startsWith('video/')) type = 'video';
      else if (file.type === 'application/pdf' || file.type.includes('word') || file.type.includes('text')) type = 'document';
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedAttachment({
          file,
          preview: reader.result as string,
          type
        });
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    // Check for payment success
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('success') === 'true') {
      toast.success('Payment successful! Your plan has been activated.');
      // Clean up the URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  const clearAttachment = () => {
    setSelectedAttachment(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const sendMessage = async (content: string, convOverride?: any) => {
    if (capacityInfo?.limitReached) {
      toast.error("You've reached today's AI usage limit.", {
        description: "Your usage resets in " + formatTimeRemaining(timeRemaining),
        id: "usage-error-limit"
      });
      return;
    }

    let conv = convOverride || currentConversation;
    const trimmed = content.trim();

    if (!trimmed && !selectedAttachment) return;
    
    if (isLoading && !convOverride) {
      console.warn("[Chat] Busy generating previous response");
      return;
    }

    // Detect and strip routing tags
    let promptTag: string | null = null;
    let cleanedContent = content;

    if (content.startsWith('@Image')) {
      promptTag = '@Image';
      cleanedContent = content.slice('@Image'.length).trim();
    } else if (content.startsWith('@Write')) {
      promptTag = '@Write';
      cleanedContent = content.slice('@Write'.length).trim();
    } else if (content.startsWith('@WebSearch')) {
      promptTag = '@WebSearch';
      cleanedContent = content.slice('@WebSearch'.length).trim();
    }

    const userMessage: Message = {
      id: safeUUID(),
      role: 'user',
      content: cleanedContent,
      image_url: selectedAttachment?.type === 'image' ? selectedAttachment.preview : undefined,
      attachment_name: selectedAttachment?.file.name,
      attachment_type: selectedAttachment?.type,
      created_at: new Date().toISOString()
    };

    // Smart Image Intent Detection
    const lowerContent = cleanedContent.toLowerCase();
    const hasImageUpload = (selectedAttachment?.type === 'image') || messages.some((m: any) => m.image_url);
    const docExclusionFilter = /\b(pdf|docx|xlsx|word|excel|spreadsheet|csv|document|resume|report|cv|curriculum\s*vitae|invoice|presentation|budget|letter|email|cover\s*letter|essay|article|post|text|contract|agreement|outline|syllabus|proposal|workbook|chart|table|schema|blueprint|database)\b/i;
    const isImageIntent = 
      promptTag === '@Image' ||
      (((conv?.type === 'image') ||
       ((/generate|create|make|draw|design|show me|give me|i want|produce|paint|illustrate|visualize|render/i.test(lowerContent)) && 
        (/image|picture|photo|logo|flyer|poster|illustration|drawing|sketch|graphic|art|realistic|scene|portrait|landscape/i.test(lowerContent))) ||
       /\b(logo|flyer|poster|art|sketch|drawing)\b/i.test(lowerContent) ||
       /image of|picture of|photo of|generate an image|create an image|make an image|generate a picture|create a picture/i.test(lowerContent) ||
       /^realistic |^photorealistic /i.test(lowerContent) ||
       (hasImageUpload && /edit|modify|change|more professional|add text|similar style|re-create|recreate/i.test(lowerContent))) &&
      !docExclusionFilter.test(lowerContent));

    const isAnalysisIntent = !!selectedAttachment;

    // Check for usage limits
    if (profile) {
      const limits = PLAN_LIMITS[profile.plan as keyof typeof PLAN_LIMITS] || PLAN_LIMITS.free;
      
      if (isImageIntent) {
        if (profile.images_used_today >= limits.images) {
          toast.error('DAILY IMAGE LIMIT REACHED', {
            description: 'You have used all your image generation credits for today.'
          });
          setUpgradeReason('images');
          setShowUpgradeModal(true);
          return;
        }
      } else if (isAnalysisIntent) {
        if (profile.analysis_used_today >= (limits.analysis || 0)) {
          toast.error('ANALYSIS LIMIT REACHED', {
            description: 'You have reached your daily limit for file analysis.'
          });
          setUpgradeReason('usage');
          setShowUpgradeModal(true);
          return;
        }
      } else {
        if (profile.messages_used_today >= limits.messages) {
          toast.error('DAILY MESSAGE LIMIT REACHED', {
            description: 'Upgrade for unlimited conversations and faster responses.'
          });
          setUpgradeReason('usage');
          setShowUpgradeModal(true);
          return;
        }
      }
    }

    // INSTANT FEEDBACK AND CLEAR INPUTS IMMEDIATELY
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    const lastInput = cleanedContent;
    setInput('');
    setActiveTag(null);
    const currentAttachment = selectedAttachment; 
    clearAttachment(); 
    setIsLoading(true);
    if (isImageIntent) {
      setIsGeneratingImage(true);
      setCurrentImagePrompt(cleanedContent);
    } else {
      setIsGeneratingImage(false);
      setCurrentImagePrompt('');
    }
    setStreamingMessage('');
    setHasError(false);
    setLastFailedRequest(null);

    if (generationAbortControllerRef.current) {
      generationAbortControllerRef.current.abort();
    }
    const controller = new AbortController();
    generationAbortControllerRef.current = controller;

    const timeoutId = setTimeout(() => {
      controller.abort();
      console.warn("[Chat] Timeout reached");
    }, 120000); // 2 minutes is safer for multi-fallback image generation and advanced searches

    try {
      // Lazy-create conversation history context if not already established (avoids blocking input on cold/slow database inserts)
      if (!conv) {
        console.log("[Chat] Lazily creating new conversation in background...");
        const type = currentAttachment ? 'general' : (isImageIntent ? 'image' : 'script');
        const rawTitle = cleanedContent.trim() || (isImageIntent ? 'Image Generation' : (currentAttachment ? 'File Analysis' : 'New Chat'));
        const title = rawTitle.length > 50 ? rawTitle.slice(0, 47) + '...' : rawTitle;
        
        const newConv = await startConversation(type, title, cleanedContent, {}, false);
        if (!newConv) {
          throw new Error("Failed to set up secure conversation channel. Please check your network connection.");
        }
        conv = newConv;
      }

      // Persist the newly sent user message to DB immediately so that on closure/refresh it is visible
      await updateConversationMessages(conv.id, updatedMessages);
      setConversations(prev => prev.map(c => c.id === conv.id ? { ...c, messages: updatedMessages, updated_at: new Date().toISOString() } : c));

      const lowerInput = cleanedContent.toLowerCase();
      const searchKeywords = [
        "news", "weather", "price", "today", "latest", "current", "2024", "2025", "2026",
        "politics", "who is", "what happened", "stock", "dollar", "usd", "ngn", "naira",
        "exchange rate", "score", "match", "result", "live", "now", "crypto",
        "happening", "event", "bitcoin", "forecast", "market", "president", 
        "how much is", "price of", "time in", "update on", "current time", "inflation",
        "election", "winner of", "standings in", "scheduled for", "rate in", "worth in",
        "who won", "yesterday", "tonight", "who is currently", "latest on"
      ];
      const isSearchIntent = promptTag === '@WebSearch' || searchKeywords.some(k => lowerInput.includes(k)) || 
                           (lowerInput.includes("?") && (lowerInput.includes("who") || lowerInput.includes("how much") || lowerInput.includes("is there") || lowerInput.includes("what happened"))) ||
                           (lowerInput.includes("2024") || lowerInput.includes("2025") || lowerInput.includes("2026"));
      
      const activeModel = selectedModelId;
      const assistantMessages = updatedMessages.filter(m => m.role === 'assistant');
      const prevModelId = assistantMessages.length > 0 ? assistantMessages[assistantMessages.length - 1].model : undefined;

      console.log(`%c[Model Used] ${activeModel} (Auto Mode: ${autoMode})`, 'color: #3b82f6; font-weight: bold; background: #eff6ff; padding: 2px 4px; border-radius: 4px;');
      console.log(`[Chat] Sending to /api/generate as type: ${isImageIntent ? 'image' : (conv.type || 'chat')}`);
      
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData?.session?.access_token;

      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          type: isImageIntent ? 'image' : (conv.type || 'chat'),
          model: activeModel,
          autoMode: autoMode,
          prevModelId: prevModelId,
          prompt: cleanedContent,
          messages: updatedMessages.map(m => ({
            role: m.role,
            content: m.content,
            image_url: m.image_url,
            model: m.model
          })),
          ready_to_copy: conv.metadata?.ready_to_copy || false,
          personality: profile?.personality || 'creative',
          conversationId: conv.id,
          userId: user?.id,
          image_speed: imageSpeed,
          is_temporary: isTemporaryChat || !!conv.is_temporary,
          webSearch: promptTag === '@WebSearch'
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        let errorMessage = 'Failed to generate';
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorMessage;
        } catch (e) {
          const text = await response.text().catch(() => '');
          errorMessage = text || `Server Error ${response.status}`;
        }
        throw new Error(errorMessage);
      }

      if (isImageIntent) {
        const data = await response.json();
        const { image_url, filename, error: backendError } = data;
        
        if (backendError) throw new Error(backendError);
        if (!image_url) throw new Error("Image generation failed - no URL produced. Please try a simpler prompt.");

        // Save to dedicated images table
        const { data: imageData, error: imageError } = await supabase.from('images').insert({
          user_id: user.id,
          prompt: content,
          image_url: image_url
        }).select().single();

        if (imageError) {
          console.error("[Chat] Image save error:", imageError);
        }

        const assistantMessage: Message = {
          id: safeUUID(),
          role: 'assistant',
          content: data.description || "Here is your generated image:",
          image_url: imageData ? `db:${imageData.id}` : image_url,
          filename: filename || `trelvix-${Date.now()}.png`,
          model: activeModel,
          created_at: new Date().toISOString()
        };
        
        const finalMessages = [...updatedMessages, assistantMessage];
        setMessages(finalMessages);
        
        await updateConversationMessages(conv.id, finalMessages);
        
        setIsLoading(false);
        setIsGeneratingImage(false);
        fetchCapacityStatus();
        return;
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullContent = '';

      if (!reader) {
        throw new Error('Streaming response not available');
      }

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value);
        fullContent += chunk;
        setStreamingMessage(prev => prev + chunk);
      }

      const assistantMessage: Message = {
        id: safeUUID(),
        role: 'assistant',
        content: fullContent,
        model: activeModel,
        created_at: new Date().toISOString()
      };

      const finalMessages = [...updatedMessages, assistantMessage];
      setMessages(finalMessages);
      setStreamingMessage('');

      await updateConversationMessages(conv.id, finalMessages);

      setIsLoading(false);
      fetchCapacityStatus();
    } catch (error: any) {
      clearTimeout(timeoutId);
      setIsGeneratingImage(false);
      
      const isAbortError = error.name === 'AbortError' || 
                           error.message?.includes('aborted') || 
                           error.message?.includes('AbortError') ||
                           error.message?.includes('signal is aborted');
                           
      if (isAbortError) {
        console.log("[Chat] Request aborted gracefully.");
        setIsLoading(false);
        return;
      }
      
      console.error("[Chat] Request Error:", error);
      
      setHasError(true);
      setLastFailedRequest({ content: lastInput, conv });
      toast.error(error.message || 'Connection failed. Please try again.');
      
      setIsLoading(false);
      fetchCapacityStatus();
    }
  };

  const handleRetry = async (messageId?: string) => {
    if (messageId) {
      // Find the user's message just before this assistant message
      const msgIdx = messages.findIndex(m => m.id === messageId);
      if (msgIdx > 0) {
        const userMsg = messages[msgIdx - 1];
        if (userMsg.role === 'user') {
          // Remove all messages from this idx onwards
          const truncatedMessages = messages.slice(0, msgIdx);
          setMessages(truncatedMessages);
          if (currentConversation?.id) {
            await updateConversationMessages(currentConversation.id, truncatedMessages);
          }
          
          // Re-send
          sendMessage(userMsg.content);
          return;
        }
      }
    }

    if (lastFailedRequest) {
      // Remove last message from state and DB first to prevent duplication
      const truncated = messages.slice(0, messages.length - 1);
      setMessages(truncated);
      if (lastFailedRequest.conv?.id) {
        await updateConversationMessages(lastFailedRequest.conv.id, truncated);
      }
      sendMessage(lastFailedRequest.content, lastFailedRequest.conv);
    } else if (messages.length > 0 && messages[messages.length - 1].role === 'user') {
      const lastUserMsg = messages[messages.length - 1];
      const truncated = messages.slice(0, messages.length - 1);
      setMessages(truncated);
      if (currentConversation?.id) {
        await updateConversationMessages(currentConversation.id, truncated);
      }
      sendMessage(lastUserMsg.content, currentConversation);
    }
  };

  const handleDownload = () => {
    if (messages.length === 0) return;
    const text = messages.map(m => `${m.role.toUpperCase()}: ${m.content}\n\n`).join('---\n\n');
    const blob = new Blob([text], { type: 'text/plain' });
    downloadFile(blob, `trelvix-chat-${currentConversation?.title || 'export'}.txt`, 'text/plain');
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast.success('Logged out successfully');
  };

  const handleRenameConversation = async (id: string, newTitle: string) => {
    try {
      const { error } = await supabase
        .from('conversations')
        .update({ title: newTitle, updated_at: new Date().toISOString() })
        .eq('id', id);

      if (error) throw error;

      setConversations(prev => prev.map(c => c.id === id ? { ...c, title: newTitle } : c));
      if (currentConversation?.id === id) {
        setCurrentConversation({ ...currentConversation, title: newTitle });
      }
      toast.success('Conversation renamed');
    } catch (error) {
      console.error("Error renaming:", error);
      toast.error('Failed to rename conversation');
    }
  };

  const handleApplyKey = async (key: string) => {
    if (!user || !profile) return;
    
    if (profile.plan === 'pro') {
      toast.info('You are already on the PRO plan');
      return;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://wxezfzhhzlauggufecmm.supabase.co';
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind4ZXpmemhoemxhdWdndWZlY21tIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQyNTQxMjcsImV4cCI6MjA4OTgzMDEyN30.2nsDSFhOtm1Xs3RuZNDo74jGbBwd05E7lPP-FN5cd1Q';

      // We use fetch directly and avoid the 'apikey' header which is causing CORS issues
      // Supabase Edge Functions accept Authorization: Bearer <token>
      const response = await fetch(`${supabaseUrl}/functions/v1/activate-pro`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token || supabaseAnonKey}`
        },
        body: JSON.stringify({ key })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        // Handle specific error cases for better UX
        if (response.status === 401 || response.status === 403) {
          throw new Error('Session expired. Please sign in again.');
        }
        throw new Error(errorData.error || `Activation failed (Status: ${response.status})`);
      }

      const data = await response.json();

      if (data?.success) {
        await fetchProfile();
        toast.success('Pro activated successfully for 30 days!');
      } else {
        // Show clear messages like "Invalid or expired key"
        const errorMessage = data?.error || 'Invalid or expired activation key. Please check and try again.';
        toast.error(errorMessage);
      }
    } catch (error: any) {
      console.error("Activation error details:", error);
      // Handle CORS/Network errors specifically
      if (error.message?.includes('Failed to fetch') || error.message?.includes('CORS')) {
        toast.error('Connection error: The activation server is currently unreachable. Please try again later.');
      } else {
        toast.error(error.message || 'Failed to activate Pro. Please try again.');
      }
    }
  };

  const handleFeedback = async (messageId: string, feedback: 'like' | 'dislike') => {
    if (!currentConversation) return;

    const updatedMessages = messages.map(m => {
      if (m.id === messageId) {
        // Toggle feedback
        return { ...m, feedback: m.feedback === feedback ? undefined : feedback };
      }
      return m;
    });

    setMessages(updatedMessages);

    try {
      await updateConversationMessages(currentConversation.id, updatedMessages);
      
      const isRemoving = messages.find(m => m.id === messageId)?.feedback === feedback;
      if (!isRemoving) {
        toast.success(feedback === 'like' ? 'Response Liked' : 'Response Disliked');
      }
    } catch (error) {
      console.error("Error saving feedback:", error);
      toast.error('Failed to save feedback');
    }
  };

  const handleShareMessage = async (m: Message) => {
    try {
      if (m.image_url) {
        // If it's an image, let's try to share the actual file if browser supports it
        let shareUrl = m.image_url;
        
        // If it's a supabase-stored image, fetch its real URL
        if (shareUrl.startsWith('db:')) {
          const imgId = shareUrl.split(':')[1];
          const { data, error } = await supabase.from('images').select('image_url').eq('id', imgId).single();
          if (!error && data?.image_url) {
            shareUrl = data.image_url;
          }
        }

        if (navigator.share && navigator.canShare) {
          try {
            const response = await fetch(shareUrl);
            const blob = await response.blob();
            const file = new File([blob], m.filename || 'trelvix-image.png', { type: blob.type });
            
            if (navigator.canShare({ files: [file] })) {
              await navigator.share({
                title: 'Trelvix AI Image',
                text: m.content || 'Check out this AI-generated image from Trelvix',
                files: [file],
                url: window.location.href
              });
              return;
            }
          } catch (fileErr) {
            console.warn("File sharing failed, falling back to text:", fileErr);
          }
        }
      }

      if (navigator.share) {
        await navigator.share({
          title: 'Trelvix AI Response',
          text: m.content,
          url: window.location.href
        });
      } else {
        const shareText = `Check out this AI response from Trelvix:\n\n${m.content}\n\nGenerated by Trelvix AI`;
        copyToClipboard(shareText);
        toast.success('Link copied to clipboard');
      }
    } catch (err) {
      console.error("Share failed:", err);
    }
  };

  const handleDownloadMessage = (content: string, id: string) => {
    const blob = new Blob([content], { type: 'text/plain' });
    downloadFile(blob, `trelvix-answer-${id.slice(0, 8)}.txt`, 'text/plain');
    toast.success('Download started');
  };

  const handleExpandImage = async (url: string, title: string) => {
    setZoomScale(1);
    setZoomPosition({ x: 0, y: 0 });
    if (!url) return;
    
    // Resolve DB reference immediately so the modal shows the full image without another loader delay
    if (url.startsWith('db:')) {
      const imgId = url.split(':')[1];
      const { data } = await supabase.from('images').select('image_url').eq('id', imgId).single();
      if (data?.image_url) {
        setExpandedImage({ url: data.image_url, title });
        return;
      }
    }
    
    setExpandedImage({ url, title });
  };

  const handleImageWheel = (e: React.WheelEvent) => {
    const zoomIntensity = 0.08;
    const delta = e.deltaY < 0 ? 1 : -1;
    const newScale = Math.min(Math.max(zoomScale + delta * zoomIntensity * zoomScale, 0.5), 6.0);
    
    setZoomScale(newScale);
    if (newScale <= 1.01) {
      setZoomPosition({ x: 0, y: 0 });
    }
  };

  const handleImageMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingImage(true);
    dragStartRef.current = {
      x: e.clientX - zoomPosition.x,
      y: e.clientY - zoomPosition.y
    };
  };

  const handleImageMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingImage) return;
    e.preventDefault();
    e.stopPropagation();
    
    if (zoomScale > 1) {
      const newX = e.clientX - dragStartRef.current.x;
      const newY = e.clientY - dragStartRef.current.y;
      setZoomPosition({ x: newX, y: newY });
    }
  };

  const handleImageMouseUpOrLeave = () => {
    setIsDraggingImage(false);
  };

  const handleImageTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const dist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
      touchStartDistRef.current = dist;
      touchStartScaleRef.current = zoomScale;
      setIsDraggingImage(false);
    } else if (e.touches.length === 1) {
      const t = e.touches[0];
      setIsDraggingImage(true);
      dragStartRef.current = {
        x: t.clientX - zoomPosition.x,
        y: t.clientY - zoomPosition.y
      };
    }
  };

  const handleImageTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && touchStartDistRef.current !== null) {
      e.preventDefault();
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const dist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
      
      const factor = dist / touchStartDistRef.current;
      const newScale = Math.min(Math.max(touchStartScaleRef.current * factor, 0.5), 6.0);
      
      setZoomScale(newScale);
      if (newScale <= 1.01) {
        setZoomPosition({ x: 0, y: 0 });
      }
    } else if (e.touches.length === 1 && isDraggingImage) {
      if (zoomScale > 1) {
        e.preventDefault();
        const t = e.touches[0];
        const newX = t.clientX - dragStartRef.current.x;
        const newY = t.clientY - dragStartRef.current.y;
        setZoomPosition({ x: newX, y: newY });
      }
    }
  };

  const handleImageTouchEnd = () => {
    touchStartDistRef.current = null;
    setIsDraggingImage(false);
  };

  const handleDownloadImage = async (url: string, filename: string) => {
    try {
      setIsDownloading(true);
      toast.loading('Preparing download...', { id: 'img-dl' });
      
      let downloadUrl = url;

      // If it's a DB reference, fetch the actual data first
      if (url.startsWith('db:')) {
        const imgId = url.split(':')[1];
        const { data, error } = await supabase.from('images').select('image_url').eq('id', imgId).single();
        if (error || !data?.image_url) throw new Error("Could not find image in database");
        downloadUrl = data.image_url;
      }

      // If it's a data URI, download directly with watermark (or without if Pro/Plus)
      const isProOrPlus = profile?.plan === 'pro' || profile?.plan === 'plus';

      if (downloadUrl.startsWith('data:')) {
        const watermarkedUrl = isProOrPlus ? downloadUrl : await applyWatermark(downloadUrl);
        await downloadFile(watermarkedUrl, filename.endsWith('.png') ? filename : `${filename}.png`, 'image/png');
        toast.success('Image download started', { id: 'img-dl' });
        return;
      }

      // Proxy fallback for remote URLs
      const response = await fetch('/api/proxy-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: downloadUrl })
      });
      
      if (!response.ok) throw new Error('Proxy fetch failed');
      
      const blob = await response.blob();
      
      // Convert blob to DataURL so we can watermark it in canvas
      const base64FromBlob = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
      
      const watermarkedUrl = isProOrPlus ? base64FromBlob : await applyWatermark(base64FromBlob);
      
      await downloadFile(watermarkedUrl, filename.endsWith('.png') ? filename : `${filename}.png`, 'image/png');
      toast.success('Image download started', { id: 'img-dl' });
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Failed to download image. It may have expired.', { id: 'img-dl' });
    } finally {
      setIsDownloading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  if (!user) return (
    <div className={cn(isDarkMode && "dark")}>
      <Auth onAuthSuccess={() => {}} isDarkMode={isDarkMode} />
      <button 
        onClick={() => setIsDarkMode(!isDarkMode)}
        className="fixed bottom-4 right-4 p-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-full shadow-lg z-50"
      >
        {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
      </button>
      <Toaster 
        position="top-center" 
        theme={isDarkMode ? 'dark' : 'light'} 
        toastOptions={{
          style: {
            background: isDarkMode ? '#09090b' : 'white',
            color: isDarkMode ? '#f4f4f5' : '#18181b',
            border: `1px solid ${isDarkMode ? '#27272a' : '#e4e4e7'}`,
            borderRadius: '12px',
            fontSize: '13px',
            fontWeight: '600',
            boxShadow: isDarkMode ? '0 10px 30px -10px rgba(0,0,0,0.5)' : '0 10px 30px -10px rgba(0,0,0,0.1)'
          }
        }}
      />
    </div>
  );

  return (
    <OrganizationProvider userId={user?.id} userEmail={user?.email}>
      {inviteToken && (
        <AcceptInvitationView 
          token={inviteToken} 
          onComplete={() => {
            setInviteToken(null);
            if (typeof window !== 'undefined') {
              window.history.replaceState({}, document.title, window.location.pathname);
            }
          }} 
        />
      )}
      <div 
        style={{ height: viewportHeight }}
        className={cn("fixed inset-0 w-full flex bg-white dark:bg-black text-zinc-900 dark:text-zinc-100 font-sans overflow-hidden", isDarkMode && "dark")}
      >
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 z-30 bg-black/40 backdrop-blur-[2px] lg:hidden cursor-pointer"
            />
          )}
        </AnimatePresence>
        <Sidebar 
          isOpen={isSidebarOpen}
          setIsOpen={setIsSidebarOpen}
          onNewChat={handleNewChat}
          onOpenSettings={(section) => {
            if (section && ['account', 'personality', 'billing', 'display', 'legal', 'support'].includes(section)) {
              setShowSettings(section as any);
            } else {
              setShowSettings(true);
            }
          }}
          onOpenSupport={() => setShowSettings('support')}
          onOpenOrgSettings={() => setActiveView('org-settings')}
          onOpenApps={() => setActiveView('apps')}
        onOpenImages={() => setActiveView('images')}
        onOpenTTS={() => setActiveView('tts')}
        onOpenVideo={() => navigateToVideoStudio()}
        onOpenLibrary={() => setActiveView('library')}
        onOpenUpgrade={() => setShowUpgradeModal(true)}
        onShowLegal={handleShowLegal}
        activeView={activeView}
        onLogout={handleLogout}
        profile={profile}
        conversations={conversations}
        currentConversationId={currentConversation?.id}
        onSelectConversation={(id) => {
          handleSelectConversation(id);
          setActiveView('chat');
        }}
        onDeleteConversation={handleDeleteConversation}
        onRenameConversation={handleRenameConversation}
        projects={projects}
        selectedProjectId={selectedProjectId}
        onSelectProject={(id) => {
          setSelectedProjectId(id);
          if (id) {
            setActiveView('project');
          } else {
            setActiveView('chat');
          }
        }}
        onOpenProjects={() => setActiveView('projects')}
        onCreateProjectClick={() => {
          setShowCreateProjectModal(true);
        }}
        onMoveConversationClick={(id) => {
          const conv = conversations.find(c => c.id === id);
          setConversationToMoveId(id);
          setMoveTargetProjectId(conv?.project_id || 'none');
        }}
      />

      <main className="flex-1 flex flex-col relative overflow-hidden">
        {/* Only show standard header for chat */}
        {activeView === 'chat' && (
          <header className={cn(
            "h-16 flex items-center justify-between px-4 transition-all duration-300 sticky top-0 z-30",
            (messages.length === 0 && !streamingMessage)
              ? "border-b border-transparent bg-transparent"
              : "border-b border-zinc-200 dark:border-zinc-800 bg-white/80 dark:bg-black/80 backdrop-blur-md"
          )}>
            {/* Left Header Section */}
            <div className="flex items-center gap-2 md:gap-3">
              {!isSidebarOpen && (
                <>
                  {/* Desktop Menu toggle */}
                  <button 
                    onClick={() => setIsSidebarOpen(true)} 
                    className="hidden sm:flex p-2 hover:bg-zinc-100 dark:hover:bg-zinc-900 rounded-lg text-zinc-600 dark:text-zinc-300 transition-colors"
                  >
                    <Menu className="w-5 h-5" />
                  </button>
                  {/* Mobile Menu toggle matching Image 2 exactly (black/dark circle, 2 lines) */}
                  <button 
                    onClick={() => setIsSidebarOpen(true)} 
                    className="flex sm:hidden w-10 h-10 items-center justify-center bg-zinc-100 dark:bg-[#1E1F22] rounded-full hover:bg-zinc-200 dark:hover:bg-zinc-800 transition-all text-zinc-800 dark:text-white border border-zinc-200 dark:border-zinc-800/60 shrink-0"
                  >
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <line x1="4" y1="8" x2="20" y2="8" />
                      <line x1="4" y1="16" x2="20" y2="16" />
                    </svg>
                  </button>
                </>
              )}
              
              {/* Upgrade/Get Plus on Left Side next to menu button, matching Image 1 exactly! */}
              {profile?.plan === 'free' && (
                <>
                  {/* Desktop Upgrade */}
                  <button 
                    onClick={() => setShowUpgradeModal(true)}
                    className="hidden sm:flex items-center gap-1.5 px-4 py-1.5 bg-zinc-100 dark:bg-[#1E1F22] border border-zinc-200 dark:border-zinc-800 rounded-full text-xs font-bold text-zinc-800 dark:text-white transition-all hover:bg-zinc-200 dark:hover:bg-zinc-800 shadow-sm shrink-0 ml-1"
                  >
                    <span className="text-[#19C37D] text-sm font-black">✦</span>
                    <span className="text-zinc-600 dark:text-zinc-200">Upgrade</span>
                  </button>
                  {/* Mobile Get Plus */}
                  <button 
                    onClick={() => setShowUpgradeModal(true)}
                    className="flex sm:hidden items-center gap-1.5 px-4.5 py-1.5 bg-zinc-100 dark:bg-[#1E1F22] border border-zinc-200 dark:border-zinc-800/85 rounded-full text-xs font-bold text-zinc-800 dark:text-white transition-all hover:bg-zinc-200 dark:hover:bg-zinc-800 shadow-xs shrink-0 ml-1.5"
                  >
                    <span className="text-[#19C37D] text-xs font-black">✦</span>
                    <span className="text-zinc-600 dark:text-zinc-200">Get Plus</span>
                  </button>
                </>
              )}

              {messages.length > 0 && (
                <>
                  <h1 className="font-bold text-base hidden md:block mr-2 text-zinc-800 dark:text-zinc-100">
                    {currentConversation 
                      ? (currentConversation.title.split(' ').slice(0, 2).join(' ') + (currentConversation.title.split(' ').length > 2 ? '...' : '')) 
                      : 'Trelvix AI'}
                  </h1>
                  <h1 className="font-bold text-sm md:hidden block max-w-[120px] truncate mr-1 text-zinc-800 dark:text-zinc-100">
                    {currentConversation 
                      ? (currentConversation.title.split(' ').slice(0, 2).join(' ') + (currentConversation.title.split(' ').length > 2 ? '...' : '')) 
                      : 'Trelvix AI'}
                  </h1>
                </>
              )}
            </div>

            {/* Right Header Section (Matches Image 1 and 2, replacing blue/purple accents with brand green) */}
            <div className="flex items-center gap-2 sm:gap-3">
              
              {/* Temporary Chat Circular Dashed Button */}
              <button 
                onClick={() => {
                  if (isTemporaryChat) {
                    setIsTemporaryChat(false);
                    handleNewChat();
                    toast("Temporary chat is OFF", { duration: 2000 });
                  } else {
                    setShowTempChatIntro(true);
                  }
                }}
                className={cn(
                  "w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-full transition-all shrink-0",
                  isTemporaryChat 
                    ? "bg-[#19C37D]/15 border border-[#19C37D]/35 text-[#19C37D]" 
                    : "bg-zinc-100 dark:bg-[#1E1F22] text-zinc-500 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800 border border-zinc-200/50 dark:border-zinc-800/60"
                )}
                title={isTemporaryChat ? "Click to turn off temporary chat" : "Turn on temporary chat to avoid saving to history"}
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeDasharray="3 2">
                  <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                </svg>
              </button>

              {/* Download Conversation option (only shown if there are active messages) */}
              {messages.length > 0 && (
                <button 
                  onClick={handleDownload}
                  className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-900 rounded-lg transition-colors text-zinc-500 dark:text-zinc-400"
                  title="Download conversation"
                >
                  <Download className="w-5 h-5" />
                </button>
              )}
            </div>
          </header>
        )}

        {/* Content Area */}
        <div className={cn(
          "flex-1 flex flex-col min-h-0",
          (activeView === 'chat' && (messages.length > 0 || streamingMessage)) || activeView === 'history' ? "overflow-y-auto overscroll-y-contain" : "overflow-hidden"
        )}>
          {activeView === 'apps' ? (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="px-6 pt-6 flex items-center justify-between md:hidden">
                <button 
                  onClick={() => setActiveView('chat')}
                  className="px-4 py-2 bg-zinc-100 dark:bg-zinc-900 rounded-xl text-xs font-bold"
                >
                  Back
                </button>
              </div>
              <AppsView 
                onBack={() => setActiveView('chat')}
                onSelectApp={(type) => {
                  if (type === 'tts') {
                    setActiveView('tts');
                  } else {
                    setShowContextForm(type);
                  }
                }} 
              />
            </div>
          ) : activeView === 'tts' ? (
            <TextToSpeechView 
              profile={profile}
              onUpgradeClick={() => setShowUpgradeModal(true)}
              onBack={() => setActiveView('chat')}
            />
          ) : activeView === 'video' ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-6 relative bg-white dark:bg-zinc-950 animate-fade-in">
              <button 
                onClick={() => setActiveView('chat')}
                className="absolute top-6 left-6 px-4 py-2 bg-zinc-100 dark:bg-zinc-900 rounded-xl text-xs font-bold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-800 transition-all cursor-pointer"
              >
                Back to Chat
              </button>
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 flex items-center justify-center">
                <Video className="w-8 h-8" />
              </div>
              <div className="space-y-2 max-w-md">
                <h2 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100">Video Studio</h2>
                <p className="text-xs text-zinc-500 font-medium leading-relaxed">
                  Video Studio is available as a dedicated service at <strong className="text-zinc-800 dark:text-zinc-200">videostudio.trelvixai.com</strong>.
                </p>
              </div>
              <button
                onClick={() => navigateToVideoStudio()}
                className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-md hover:shadow-emerald-500/20 flex items-center gap-2 cursor-pointer active:scale-95"
              >
                <span>Launch Video Studio (videostudio.trelvixai.com)</span>
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>
          ) : activeView === 'library' ? (
            <LibraryView 
              profile={profile}
              onUpgradeClick={() => setShowUpgradeModal(true)}
              onBack={() => setActiveView('chat')}
            />
          ) : activeView === 'images' ? (
            <div className="flex-1 flex flex-col items-center justify-center p-12 text-center space-y-8 relative">
              <button 
                onClick={() => setActiveView('chat')}
                className="absolute top-6 left-6 px-4 py-2 bg-zinc-100 dark:bg-zinc-900 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-zinc-200 dark:hover:bg-zinc-800 transition-all"
              >
                Return to Chat
              </button>
              <ImageIcon className="w-16 h-16 text-orange-500" />
              <div className="space-y-4">
                <h2 className="text-4xl font-bold tracking-tight">Image Studio</h2>
                <p className="text-zinc-500 font-medium max-w-sm mx-auto mt-4 leading-relaxed">Generate high-fidelity AI images with proprietary studio quality.</p>
              </div>
              <button 
                onClick={() => {
                  setShowContextForm('image');
                }}
                className="px-8 py-4 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-2xl font-bold shadow-xl active:scale-[0.98] transition-all hover:shadow-orange-500/20"
              >
                Generate New Image
              </button>
            </div>
          ) : activeView === 'history' ? (
            <div className="max-w-4xl mx-auto w-full p-6 space-y-4">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-bold tracking-tight">Chat History</h2>
                <button 
                  onClick={() => setActiveView('chat')}
                  className="px-4 py-2 bg-zinc-100 dark:bg-zinc-900 rounded-xl text-xs font-semibold hover:bg-zinc-200 dark:hover:bg-zinc-800 transition-all text-zinc-600 dark:text-zinc-400"
                >
                  Back to Chat
                </button>
              </div>
              {conversations.length === 0 ? (
                <div className="text-center py-20 opacity-50 flex flex-col items-center gap-4">
                  <div className="w-16 h-16 bg-zinc-100 dark:bg-zinc-900 rounded-full flex items-center justify-center">
                    <HistoryIcon className="w-8 h-8 opacity-20" />
                  </div>
                  <div className="font-bold">No chats yet. Start a new one!</div>
                </div>
              ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-12">
                    {conversations.map((conv, index) => (
                      <div
                        key={`history-conv-${conv.id || index}`}
                        className="p-6 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl text-left hover:border-zinc-400 dark:hover:border-zinc-600 transition-all group relative hover:shadow-xl"
                      >
                      <div onClick={() => {
                        handleSelectConversation(conv.id);
                        setActiveView('chat');
                      }} className="cursor-pointer">
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-[10px] font-black uppercase tracking-widest px-2 py-1 bg-zinc-100 dark:bg-zinc-800 rounded-lg">{conv.type}</span>
                          <span className="text-[10px] font-bold opacity-40 uppercase tracking-widest">{new Date(conv.created_at).toLocaleDateString()}</span>
                        </div>
                        <h3 className="font-bold mb-2 group-hover:text-zinc-900 dark:group-hover:text-white transition-colors">{conv.title}</h3>
                        <p className="text-xs opacity-60 line-clamp-2 leading-relaxed">
                          {conv.messages?.[0]?.content || 'No messages yet'}
                        </p>
                      </div>
                      
                      <div className="mt-6 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => {
                            const newTitle = prompt('Rename conversation:', conv.title);
                            if (newTitle) handleRenameConversation(conv.id, newTitle);
                          }}
                          className="flex-1 py-2 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                        >
                          Rename
                        </button>
                        <button 
                          onClick={() => handleDeleteConversation(conv.id)}
                          className="flex-1 py-2 bg-red-50 dark:bg-red-950/20 hover:bg-red-100 text-red-500 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : activeView === 'project' ? (
            <div className="flex-1 flex flex-col overflow-y-auto overscroll-y-contain animate-fade-in bg-white dark:bg-zinc-950">
              <div className="max-w-4xl mx-auto w-full p-6 md:p-12 space-y-8 pb-32">
                {(() => {
                  const proj = projects.find(p => p.id === selectedProjectId);
                  if (!proj) {
                    return (
                      <div className="text-center py-20 opacity-50 flex flex-col items-center gap-4 animate-fade-in">
                        <div className="w-16 h-16 bg-zinc-100 dark:bg-zinc-900 rounded-full flex items-center justify-center">
                          <Folder className="w-8 h-8 opacity-20" />
                        </div>
                        <div className="font-bold text-zinc-900 dark:text-zinc-100">Project Not Found</div>
                        <button
                          onClick={() => {
                            setSelectedProjectId(null);
                            setActiveView('projects');
                          }}
                          className="px-4 py-2 bg-zinc-100 dark:bg-zinc-800 text-xs font-bold rounded-xl cursor-pointer"
                        >
                          Back to Projects
                        </button>
                      </div>
                    );
                  }
                  
                  const projConversations = conversations.filter(c => c.project_id === proj.id);
                  
                  return (
                    <div className="space-y-8 animate-fade-in">
                      {/* Back Navigation Button */}
                      <div>
                        <button
                          onClick={() => {
                            setSelectedProjectId(null);
                            setActiveView('projects');
                          }}
                          className="inline-flex items-center gap-2 text-xs font-bold text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition-colors cursor-pointer group"
                        >
                          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                          <span>Back to Projects</span>
                        </button>
                      </div>

                      {/* Project Header Card */}
                      <div className="bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200/80 dark:border-zinc-800/80 rounded-3xl p-6 md:p-8 space-y-6">
                        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                          <div className="space-y-3 flex-1 min-w-0">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold shrink-0">
                                <Folder className="w-5 h-5" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold uppercase tracking-wider">
                                    Project
                                  </span>
                                  <span className="text-[10px] font-mono text-zinc-400">
                                    Updated {proj.updated_at ? new Date(proj.updated_at).toLocaleDateString() : 'recently'}
                                  </span>
                                </div>
                                <h1 className="text-2xl md:text-3xl font-bold text-zinc-900 dark:text-white tracking-tight mt-1 truncate">
                                  {proj.title}
                                </h1>
                              </div>
                            </div>

                            {proj.description ? (
                              <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed pt-1">
                                {proj.description}
                              </p>
                            ) : (
                              <p className="text-xs text-zinc-400 italic pt-1">
                                No description added for this project.
                              </p>
                            )}
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              onClick={() => setShowProjectSettingsModal(true)}
                              className="px-3.5 py-2.5 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-xl text-xs font-bold transition-all cursor-pointer bg-white dark:bg-zinc-900 flex items-center gap-2 shadow-xs"
                            >
                              <SettingsIcon className="w-3.5 h-3.5" />
                              <span>Settings</span>
                            </button>
                            <button
                              onClick={() => handleDeleteProject(proj.id)}
                              className="p-2.5 border border-red-200 dark:border-red-950/40 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 rounded-xl text-xs font-bold transition-all cursor-pointer"
                              title="Delete Project"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => {
                                handleNewChat();
                                setActiveView('chat');
                              }}
                              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-md hover:shadow-emerald-500/20 active:scale-[0.98] cursor-pointer flex items-center gap-2"
                            >
                              <Plus className="w-4 h-4" />
                              <span>New Chat</span>
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Project Conversations List */}
                      <div className="space-y-4">
                        <div className="flex items-center justify-between px-1">
                          <h2 className="text-sm font-bold text-zinc-900 dark:text-white">Project Conversations</h2>
                          <span className="text-xs font-mono text-zinc-400">{projConversations.length} {projConversations.length === 1 ? 'chat' : 'chats'}</span>
                        </div>

                        {projConversations.length === 0 ? (
                          <div className="text-center py-16 px-6 bg-zinc-50/50 dark:bg-zinc-900/30 border border-dashed border-zinc-200 dark:border-zinc-800 rounded-3xl space-y-4 max-w-lg mx-auto my-4">
                            <div className="w-12 h-12 rounded-2xl bg-zinc-100 dark:bg-zinc-800 text-zinc-400 flex items-center justify-center mx-auto">
                              <MessageSquare className="w-6 h-6" />
                            </div>
                            <div className="space-y-1">
                              <h3 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">No conversations in this project yet</h3>
                              <p className="text-xs text-zinc-500 max-w-xs mx-auto leading-relaxed">
                                Start a chat inside <strong className="text-zinc-700 dark:text-zinc-300">{proj.title}</strong> to organize your work.
                              </p>
                            </div>
                            <button
                              onClick={() => {
                                handleNewChat();
                                setActiveView('chat');
                              }}
                              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition-all shadow-md hover:shadow-emerald-500/20 inline-flex items-center gap-2 cursor-pointer active:scale-95"
                            >
                              <Plus className="w-4 h-4" />
                              <span>Start Chat</span>
                            </button>
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-12">
                            {projConversations.map((conv, index) => (
                              <div
                                key={`proj-conv-${conv.id || index}`}
                                className="p-5 bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800/80 rounded-2xl text-left hover:border-zinc-300 dark:hover:border-zinc-700 transition-all group relative shadow-xs hover:shadow-md flex flex-col justify-between"
                              >
                                <div 
                                  onClick={() => {
                                    handleSelectConversation(conv.id);
                                    setActiveView('chat');
                                  }} 
                                  className="cursor-pointer flex-1"
                                >
                                  <div className="flex items-center justify-between mb-3">
                                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 rounded-md">
                                      {conv.type || 'Chat'}
                                    </span>
                                    <span className="text-[10px] font-mono text-zinc-400">
                                      {new Date(conv.created_at).toLocaleDateString()}
                                    </span>
                                  </div>
                                  <h3 className="font-bold text-sm text-zinc-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors line-clamp-1 mb-1">
                                    {conv.title || 'Untitled Chat'}
                                  </h3>
                                  <p className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2 leading-relaxed">
                                    {conv.messages?.[0]?.content || 'No messages yet'}
                                  </p>
                                </div>
                                
                                <div className="mt-4 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity pt-3 border-t border-zinc-100 dark:border-zinc-800/80">
                                  <button 
                                    onClick={() => {
                                      const newTitle = prompt('Rename conversation:', conv.title);
                                      if (newTitle) handleRenameConversation(conv.id, newTitle);
                                    }}
                                    className="flex-1 py-1.5 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 rounded-lg text-[10px] font-bold transition-all cursor-pointer text-zinc-700 dark:text-zinc-300"
                                  >
                                    Rename
                                  </button>
                                  <button 
                                    onClick={() => handleRemoveFromProject(conv.id)}
                                    className="flex-1 py-1.5 bg-amber-50 dark:bg-amber-950/20 hover:bg-amber-100 text-amber-600 dark:text-amber-400 rounded-lg text-[10px] font-bold transition-all cursor-pointer"
                                    title="Move out of project"
                                  >
                                    Remove
                                  </button>
                                  <button 
                                    onClick={() => handleDeleteConversation(conv.id)}
                                    className="flex-1 py-1.5 bg-red-50 dark:bg-red-950/20 hover:bg-red-100 text-red-500 rounded-lg text-[10px] font-bold transition-all cursor-pointer"
                                  >
                                    Delete
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })()}
              </div>
            </div>
          ) : activeView === 'projects' ? (
            <div className="flex-1 flex flex-col overflow-y-auto overscroll-y-contain animate-fade-in bg-white dark:bg-zinc-950">
              <div className="max-w-5xl mx-auto w-full p-6 md:p-12 space-y-8 pb-32">
                {/* Header Section */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-200 dark:border-zinc-800 pb-6">
                  <div>
                    <h1 className="text-2xl md:text-3xl font-bold text-zinc-900 dark:text-white tracking-tight">Projects</h1>
                    <p className="text-xs text-zinc-500 font-medium mt-1">Organize your AI chats, code, and custom instructions into dedicated projects.</p>
                  </div>

                  <button 
                    onClick={() => setShowCreateProjectModal(true)}
                    className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition-all shadow-sm hover:shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer active:scale-95 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    <span>New Project</span>
                  </button>
                </div>

                {/* Search & Counter Bar */}
                <div className="flex items-center gap-3">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                    <input
                      type="text"
                      value={projectSearchQuery}
                      onChange={(e) => setProjectSearchQuery(e.target.value)}
                      placeholder="Search projects..."
                      className="w-full pl-10 pr-9 py-2.5 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs font-medium text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                    />
                    {projectSearchQuery && (
                      <button 
                        onClick={() => setProjectSearchQuery('')}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <span className="text-xs font-mono text-zinc-500 px-3 py-2.5 bg-zinc-100 dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 shrink-0 font-medium">
                    {projects.filter(p => p.title.toLowerCase().includes(projectSearchQuery.toLowerCase()) || (p.description || '').toLowerCase().includes(projectSearchQuery.toLowerCase())).length} {projects.filter(p => p.title.toLowerCase().includes(projectSearchQuery.toLowerCase()) || (p.description || '').toLowerCase().includes(projectSearchQuery.toLowerCase())).length === 1 ? 'project' : 'projects'}
                  </span>
                </div>

                {/* Projects Cards Grid */}
                {(() => {
                  const filteredList = projects.filter(p => 
                    p.title.toLowerCase().includes(projectSearchQuery.toLowerCase()) || 
                    (p.description || '').toLowerCase().includes(projectSearchQuery.toLowerCase())
                  );

                  if (filteredList.length === 0) {
                    return (
                      <div className="text-center py-16 px-6 bg-zinc-50/50 dark:bg-zinc-900/30 border border-dashed border-zinc-200 dark:border-zinc-800 rounded-3xl space-y-4 max-w-sm mx-auto my-6 animate-fade-in">
                        <div className="w-12 h-12 rounded-2xl bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-400 flex items-center justify-center mx-auto">
                          <Folder className="w-6 h-6 opacity-60" />
                        </div>
                        <div className="space-y-1">
                          <h3 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">
                            {projectSearchQuery ? 'No matching projects' : 'No projects created yet'}
                          </h3>
                          <p className="text-xs text-zinc-500 leading-relaxed">
                            {projectSearchQuery 
                              ? 'Try searching with a different term.' 
                              : 'Create a project to organize your chat sessions and group custom instructions.'}
                          </p>
                        </div>
                        {!projectSearchQuery && (
                          <button
                            onClick={() => setShowCreateProjectModal(true)}
                            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition-all shadow-sm inline-flex items-center gap-2 cursor-pointer"
                          >
                            <Plus className="w-4 h-4" />
                            <span>Create Project</span>
                          </button>
                        )}
                      </div>
                    );
                  }

                  return (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredList.map((proj) => {
                        const projConvs = conversations.filter(c => c.project_id === proj.id);
                        const isSelected = selectedProjectId === proj.id;
                        
                        return (
                          <div
                            key={`projects-screen-card-${proj.id}`}
                            className={cn(
                              "p-5 bg-white dark:bg-zinc-900/80 border rounded-2xl transition-all duration-200 flex flex-col justify-between group relative shadow-xs hover:shadow-md",
                              isSelected 
                                ? "border-emerald-500/60 ring-2 ring-emerald-500/20" 
                                : "border-zinc-200/80 dark:border-zinc-800/80 hover:border-zinc-300 dark:hover:border-zinc-700"
                            )}
                          >
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                                  <Folder className="w-4.5 h-4.5" />
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedProjectId(proj.id);
                                      setShowProjectSettingsModal(true);
                                    }}
                                    className="p-1 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 rounded-lg transition-all cursor-pointer"
                                    title="Rename Project"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 font-medium">
                                    {projConvs.length} {projConvs.length === 1 ? 'chat' : 'chats'}
                                  </span>
                                </div>
                              </div>

                              <div>
                                <h3 className="font-bold text-base text-zinc-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors line-clamp-1">
                                  {proj.title}
                                </h3>
                                <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 line-clamp-2 leading-relaxed min-h-[2.25rem]">
                                  {proj.description || 'No description provided.'}
                                </p>
                              </div>
                            </div>

                            <div className="pt-4 mt-3 border-t border-zinc-100 dark:border-zinc-800/80 space-y-2.5">
                              <div className="flex items-center justify-between text-[10px] font-mono text-zinc-400">
                                <span>UPDATED</span>
                                <span>{proj.updated_at ? new Date(proj.updated_at).toLocaleDateString() : 'Recently'}</span>
                              </div>

                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => {
                                    setSelectedProjectId(proj.id);
                                    setActiveView('project');
                                  }}
                                  className="flex-1 py-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 hover:bg-zinc-800 dark:hover:bg-zinc-100 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                                >
                                  <span>Open</span>
                                  <ChevronRight className="w-3.5 h-3.5" />
                                </button>

                                <button
                                  onClick={() => handleDeleteProject(proj.id)}
                                  className="px-3 py-2 bg-red-50 dark:bg-red-950/20 hover:bg-red-100 dark:hover:bg-red-950/40 text-red-500 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                                  title="Delete Project"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>Delete</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            </div>
          ) : activeView === 'org-settings' ? (
            <OrganizationSettings onBack={() => setActiveView('chat')} userId={user?.id} />
          ) : (
            <>
              {messages.length === 0 && !streamingMessage ? (
                <WelcomeScreen 
                  input={input}
                  setInput={setInput}
                  sendMessage={sendMessage}
                  selectedModelId={selectedModelId}
                  onSelectModel={handleSelectModel}
                  userPlan={profile?.plan || 'free'}
                  onUpgradeClick={() => setShowUpgradeModal(true)}
                  onUploadClick={() => fileInputRef.current?.click()}
                  selectedAttachment={selectedAttachment}
                  clearAttachment={clearAttachment}
                  isLoading={isLoading}
                  textareaRef={textareaRef}
                  isTemporaryChat={isTemporaryChat}
                  activeTag={activeTag}
                  setActiveTag={setActiveTag}
                  handleInputChange={handleInputChange}
                  onStartLiveMode={() => {
                    playLiveOpenSound();
                    setShowLiveMode(true);
                  }}
                />
              ) : (
                <div className="max-w-3xl mx-auto w-full px-4 py-8 md:py-12 space-y-10 pb-36">
                  {messages.map((m, index) => (
                    <div 
                      key={`chat-msg-${m.id || index}`} 
                      onClick={() => setActiveMessageId(activeMessageId === m.id ? null : m.id)}
                      className={cn(
                        "flex w-full cursor-pointer md:cursor-default",
                        m.role === 'user' ? "justify-end" : "justify-start"
                      )}
                    >
                      <div className={cn(
                        "flex flex-col group relative transition-all duration-200",
                        m.role === 'user' ? "max-w-[85%] md:max-w-[75%] items-end" : "w-full"
                      )}>
                        <div className={cn(
                          "w-full text-[15px] sm:text-base transition-all duration-200",
                          m.role === 'user' 
                            ? "bg-emerald-500/10 dark:bg-emerald-900/20 border border-emerald-500/20 dark:border-emerald-800/30 rounded-2xl md:rounded-[1.75rem] px-5 py-3.5 shadow-sm text-zinc-900 dark:text-zinc-50"
                            : "bg-transparent text-zinc-900 dark:text-zinc-100 border-none shadow-none px-0 py-1"
                        )}>
                          <div className={cn(
                            "prose dark:prose-invert max-w-none leading-relaxed prose-headings:font-normal prose-strong:font-normal prose-th:font-normal",
                            m.role === 'user' 
                              ? "font-normal text-zinc-800 dark:text-zinc-200 text-[15px] sm:text-base md:leading-normal tracking-tight" 
                              : "prose-base text-[15px] md:text-base text-zinc-750 dark:text-zinc-300"
                          )}>
                            <ReactMarkdown 
                              remarkPlugins={[remarkMath, ...(loadedRemarkGfm ? [loadedRemarkGfm] : [])]}
                              rehypePlugins={[rehypeKatex]}
                              components={{
                                code({ node, inline, className, children, ...props }: any) {
                                  const isJsonFileData = !inline && (className?.includes('json-file-data') || className?.includes('language-json-file-data'));
                                  if (isJsonFileData) {
                                    return <DocumentExportCard jsonData={String(children)} isPro={profile?.plan === 'pro' || profile?.plan === 'plus'} />;
                                  }
                                  return (
                                    <CodeBlock inline={inline} className={className}>
                                      {children}
                                    </CodeBlock>
                                  );
                                },
                                strong({ children }) {
                                  return <span className="font-normal text-zinc-900 dark:text-zinc-100 inline">{children}</span>;
                                },
                                b({ children }) {
                                  return <span className="font-normal text-zinc-900 dark:text-zinc-100 inline">{children}</span>;
                                },
                                h1({ children }) {
                                  return <span className="block text-xl font-normal text-zinc-900 dark:text-zinc-100 mt-4 mb-2">{children}</span>;
                                },
                                h2({ children }) {
                                  return <span className="block text-lg font-normal text-zinc-900 dark:text-zinc-100 mt-4 mb-2">{children}</span>;
                                },
                                h3({ children }) {
                                  return <span className="block text-base font-normal text-zinc-900 dark:text-zinc-100 mt-3 mb-1">{children}</span>;
                                },
                                h4({ children }) {
                                  return <span className="block text-sm font-normal text-zinc-900 dark:text-zinc-100 mt-3 mb-1">{children}</span>;
                                }
                              }}
                            >
                              {preprocessMath(m.content)}
                            </ReactMarkdown>
                          </div>

                          {/* Generic Attachment Display */}
                          {m.attachment_type && m.attachment_type !== 'image' && (
                            <div className="mt-3 mb-2 p-3 bg-zinc-50 dark:bg-zinc-800/30 border border-zinc-200/60 dark:border-zinc-800/40 rounded-2xl flex items-center gap-3 w-fit min-w-[200px] max-w-full overflow-hidden shadow-sm">
                              <div className="w-10 h-10 shrink-0 rounded-lg bg-zinc-200/60 dark:bg-zinc-800 flex items-center justify-center text-zinc-600 dark:text-zinc-400">
                                {m.attachment_type === 'video' ? <Film className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="text-sm font-semibold truncate text-zinc-900 dark:text-zinc-100">{m.attachment_name || 'Attached file'}</p>
                                <p className="text-[10px] opacity-50 uppercase tracking-wider font-extrabold">{m.attachment_type}</p>
                              </div>
                            </div>
                          )}

                          {m.image_url && (
                            <div className="mt-4 max-w-xl rounded-2xl overflow-hidden border border-zinc-200/80 dark:border-zinc-800/60 bg-zinc-50 dark:bg-zinc-900/40">
                              <div 
                                className="relative group/img cursor-zoom-in"
                                onClick={(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  handleExpandImage(m.image_url!, m.content);
                                }}
                              >
                                <ImageWithLoader 
                                  src={m.image_url} 
                                  alt="Generated" 
                                  className="w-full"
                                  skipWatermark={profile?.plan === 'pro' || profile?.plan === 'plus'}
                                />
                                <div className="absolute inset-0 bg-black/0 group-hover/img:bg-black/20 transition-colors flex items-center justify-center opacity-0 group-hover/img:opacity-100">
                                  <Maximize2 className="w-8 h-8 text-white drop-shadow-lg" />
                                </div>
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="mt-2.5 flex items-center justify-between w-full">
                          <div className="text-[10px] opacity-40 flex items-center gap-2">
                            <span>{new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                          <div className={cn(
                            "flex items-center gap-1.5 md:gap-2 transition-all duration-200",
                            activeMessageId === m.id ? "opacity-100 translate-y-0" : "opacity-0 md:group-hover:opacity-100 translate-y-1 md:translate-y-0"
                          )}>
                            <button 
                              onClick={(e) => { e.stopPropagation(); copyToClipboard(m.content); }}
                              className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition-colors shrink-0"
                              title="Copy to clipboard"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                            
                            <button 
                              onClick={(e) => { e.stopPropagation(); handleShareMessage(m); }}
                              className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-zinc-500 dark:hover:text-zinc-400 transition-colors shrink-0"
                              title="Share message"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </button>

                            {m.role === 'assistant' && (
                              <>
                                <div className="h-4 w-[1px] bg-zinc-200 dark:bg-zinc-800 mx-0.5 shrink-0" />
                                
                                <button 
                                  onClick={(e) => { e.stopPropagation(); handleFeedback(m.id, 'like'); }}
                                  className={cn(
                                    "p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-lg transition-colors shrink-0",
                                    m.feedback === 'like' ? "text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20" : "text-zinc-500 hover:text-zinc-900 dark:hover:text-white"
                                  )}
                                  title="Like response"
                                >
                                  <ThumbsUp className="w-3.5 h-3.5" />
                                </button>
                                
                                <button 
                                  onClick={(e) => { e.stopPropagation(); handleFeedback(m.id, 'dislike'); }}
                                  className={cn(
                                    "p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-lg transition-colors shrink-0",
                                    m.feedback === 'dislike' ? "text-rose-600 bg-rose-50 dark:bg-rose-950/20" : "text-zinc-500 hover:text-zinc-900 dark:hover:text-white"
                                  )}
                                  title="Dislike response"
                                >
                                  <ThumbsDown className="w-3.5 h-3.5" />
                                </button>

                                <button 
                                  onClick={(e) => { e.stopPropagation(); handleRetry(m.id); }}
                                  className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition-colors shrink-0"
                                  title="Retry response"
                                >
                                  <Plus className="w-4 h-4 rotate-45" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Consolidated simple error UI */}
                  {((hasError || (messages.length > 0 && messages[messages.length - 1].role === 'user')) && !isLoading && !streamingMessage) && (
                    <motion.div 
                      key="error-state"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex justify-start py-4"
                    >
                      <div className="flex flex-col gap-2 p-4 bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-sm max-w-sm">
                        <div className="flex items-center gap-3">
                          <div className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                          </div>
                          <span className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                            Checking background generation...
                          </span>
                        </div>
                        <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
                          The server continues running in the background if your screen went off or was interrupted. We will retrieve and display your response the instant it finishes.
                        </p>
                        <div className="flex items-center gap-4 mt-2 pt-2 border-t border-zinc-200/50 dark:border-zinc-800/80">
                          <button 
                            onClick={() => handleRetry()}
                            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline active:scale-95 flex items-center gap-1.5 transition-all"
                          >
                            <span>Force Retry</span>
                            <Plus className="w-3.5 h-3.5 rotate-45 text-emerald-600 dark:text-emerald-400" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                  {(isLoading || streamingMessage) && (
                    <div className="flex justify-start w-full">
                      <div className="w-full bg-transparent text-zinc-900 dark:text-zinc-100 border-none shadow-none px-0 py-1 relative">
                        {streamingMessage ? (
                          <div className="prose dark:prose-invert prose-sm md:prose-base max-w-none leading-relaxed prose-headings:font-normal prose-strong:font-normal prose-th:font-normal">
                            <ReactMarkdown 
                              remarkPlugins={[remarkMath, ...(loadedRemarkGfm ? [loadedRemarkGfm] : [])]}
                              rehypePlugins={[rehypeKatex]}
                              components={{
                                code({ node, inline, className, children, ...props }: any) {
                                  const isJsonFileData = !inline && (className?.includes('json-file-data') || className?.includes('language-json-file-data'));
                                  if (isJsonFileData) {
                                    return <DocumentExportCard jsonData={String(children)} isPro={profile?.plan === 'pro' || profile?.plan === 'plus'} />;
                                  }
                                  return (
                                    <CodeBlock inline={inline} className={className}>
                                      {children}
                                    </CodeBlock>
                                  );
                                },
                                strong({ children }) {
                                  return <span className="font-normal text-zinc-900 dark:text-zinc-100 inline">{children}</span>;
                                },
                                b({ children }) {
                                  return <span className="font-normal text-zinc-900 dark:text-zinc-100 inline">{children}</span>;
                                },
                                h1({ children }) {
                                  return <span className="block text-xl font-normal text-zinc-900 dark:text-zinc-100 mt-4 mb-2">{children}</span>;
                                },
                                h2({ children }) {
                                  return <span className="block text-lg font-normal text-zinc-900 dark:text-zinc-100 mt-4 mb-2">{children}</span>;
                                },
                                h3({ children }) {
                                  return <span className="block text-base font-normal text-zinc-900 dark:text-zinc-100 mt-3 mb-1">{children}</span>;
                                },
                                h4({ children }) {
                                  return <span className="block text-sm font-normal text-zinc-900 dark:text-zinc-100 mt-3 mb-1">{children}</span>;
                                }
                              }}
                            >
                              {preprocessMath(streamingMessage)}
                            </ReactMarkdown>
                            <span className="inline-block w-2.5 h-4.5 ml-1 bg-zinc-900 dark:bg-white animate-pulse rounded-sm align-middle" />
                          </div>
                        ) : isGeneratingImage ? (
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.98 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0 }}
                            className="mt-4 flex flex-col items-start gap-2"
                          >
                            <div className="relative w-72 h-72 sm:w-80 sm:h-80 aspect-square rounded-[24px] overflow-hidden bg-zinc-100/70 dark:bg-zinc-900/40 border border-zinc-200/50 dark:border-zinc-800/40 flex flex-col items-center justify-center shadow-inner animate-pulse">
                              <div className="flex flex-col items-center gap-3">
                                <Loader2 className="w-5 h-5 text-zinc-400 dark:text-zinc-500 animate-spin" />
                                <span className="text-zinc-400 dark:text-zinc-500 text-xs font-medium tracking-tight">
                                  Generating image...
                                </span>
                              </div>
                            </div>
                          </motion.div>
                        ) : (
                          <QueueStatusLoader userPlan={profile?.plan || 'free'} />
                        )}
                      </div>
                    </div>
                  )}

                  <div ref={messagesEndRef} />
                </div>
              )}
            </>
          )}
        </div>

        {/* Input Area */}
        {activeView === 'chat' && (messages.length > 0 || streamingMessage) && (
          <div className="relative p-3 pb-4 sm:p-6 md:p-8 bg-white dark:bg-black border-t border-zinc-100 dark:border-zinc-900/50">
            <div className="max-w-4xl mx-auto space-y-2 md:space-y-6">
              {capacityInfo?.limitReached ? (
                <div className="w-full flex flex-col items-center justify-center py-8 px-6 border border-zinc-200/60 dark:border-zinc-800/80 rounded-[2rem] md:rounded-[2.5rem] bg-zinc-50/50 dark:bg-zinc-900/30 text-center select-none animate-fade-in backdrop-blur-sm shadow-sm">
                  <div className="p-3 bg-red-100 dark:bg-red-950/30 text-red-600 dark:text-red-400 rounded-full mb-3 shadow-inner">
                    <AlertCircle className="w-6 h-6 animate-pulse" />
                  </div>
                  <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-50">
                    You've reached today's AI usage limit
                  </h3>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
                    Your usage resets in
                  </p>
                  <div className="text-xl font-mono font-black text-zinc-800 dark:text-zinc-100 mt-2 tracking-widest bg-zinc-100 dark:bg-zinc-800/50 px-4 py-1.5 rounded-xl border border-zinc-200/50 dark:border-zinc-700/30 shadow-inner">
                    {formatTimeRemaining(timeRemaining)}
                  </div>
                  <button 
                    onClick={() => {
                      setUpgradeReason('usage');
                      setShowUpgradeModal(true);
                    }}
                    className="mt-5 px-5 py-2.5 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 text-xs md:text-sm font-bold uppercase tracking-widest rounded-full hover:opacity-90 active:scale-95 transition-all shadow-md animate-bounce"
                  >
                    Upgrade Plan for higher limits
                  </button>
                </div>
              ) : (
                <div className="bg-zinc-100 dark:bg-[#1E1F22] border border-zinc-200/40 dark:border-zinc-800/60 rounded-full shadow-lg focus-within:ring-2 focus-within:ring-zinc-900/5 dark:focus-within:ring-white/5 transition-all relative z-20 overflow-visible">
                <AnimatePresence>
                  {selectedAttachment && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="border-b border-zinc-200/40 dark:border-zinc-800/60 bg-zinc-100/50 dark:bg-zinc-800/30 p-2 md:p-4 rounded-t-[28px]"
                    >
                      <div className="relative group/preview w-24 h-20 md:w-32 md:h-24 rounded-xl md:rounded-2xl overflow-hidden bg-white dark:bg-zinc-800 flex items-center justify-center border border-zinc-200 dark:border-zinc-700 shadow-sm">
                        {selectedAttachment.type === 'image' ? (
                          <img src={selectedAttachment.preview} alt="Upload Preview" className="w-full h-full object-cover" />
                        ) : (
                          <div className="flex flex-col items-center gap-1 md:gap-2 text-zinc-400">
                            {selectedAttachment.type === 'video' ? <Film className="w-5 h-5 md:w-6 md:h-6" /> : <FileText className="w-5 h-5 md:w-6 md:h-6" />}
                            <span className="text-[8px] md:text-[10px] font-black truncate max-w-[80px] md:max-w-[100px] uppercase tracking-widest">{selectedAttachment.file.name}</span>
                          </div>
                        )}
                        <button 
                          onClick={clearAttachment}
                          className="absolute top-1 right-1 md:top-2 md:right-2 p-1 md:p-1.5 bg-black/50 text-white rounded-full hover:bg-black transition-all opacity-100 md:opacity-0 md:group-hover/preview:opacity-100 scale-90 md:group-hover/preview:scale-100"
                        >
                          <X className="w-3.5 h-3.5 md:w-4 md:h-4" />
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="flex items-center px-2 sm:px-3 py-1.5 min-h-[48px] sm:min-h-[52px] relative overflow-visible">
                  <input 
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  
                  {/* Left Plus button (visible on both mobile and desktop) */}
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2 text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200 rounded-full hover:bg-zinc-200/50 dark:hover:bg-zinc-800/50 transition-colors shrink-0"
                    title="Upload file or attachment"
                  >
                    <Plus className="w-5 h-5 font-bold" />
                  </button>

                  {/* Middle Container: Tag Pill and Textarea */}
                  <div className="flex-1 flex items-center gap-1.5 sm:gap-2 min-w-0">
                    {activeTag && (
                      <div className="flex items-center gap-1 bg-zinc-200 dark:bg-zinc-800 border border-zinc-300/40 dark:border-zinc-700/40 text-zinc-800 dark:text-zinc-200 px-2.5 py-1 rounded-full text-xs font-semibold select-none shrink-0 animate-fade-in">
                        {activeTag === '@Image' && <ImageIcon className="w-3.5 h-3.5 text-zinc-500 dark:text-zinc-400" />}
                        {activeTag === '@Write' && <Edit3 className="w-3.5 h-3.5 text-zinc-500 dark:text-zinc-400" />}
                        {activeTag === '@WebSearch' && <Globe className="w-3.5 h-3.5 text-zinc-500 dark:text-zinc-400" />}
                        <span>{activeTag}</span>
                        <button 
                          type="button"
                          onClick={() => setActiveTag(null)}
                          className="p-0.5 hover:bg-zinc-300 dark:hover:bg-zinc-700 rounded-full transition-colors ml-0.5"
                        >
                          <X className="w-3 h-3 text-zinc-500 dark:text-zinc-400" />
                        </button>
                      </div>
                    )}

                    {/* Textarea */}
                    <textarea
                      ref={textareaRef}
                      rows={1}
                      value={input}
                      onChange={(e) => handleInputChange(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Backspace' && textareaRef.current && textareaRef.current.selectionStart === 0 && textareaRef.current.selectionEnd === 0 && activeTag) {
                          e.preventDefault();
                          setActiveTag(null);
                        } else if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          sendMessage(activeTag ? `${activeTag} ${input}` : input);
                        }
                      }}
                      placeholder={ 
                        activeTag ? "" : (
                        profile && profile.messages_used_today >= (PLAN_LIMITS[profile.plan as keyof typeof PLAN_LIMITS] || PLAN_LIMITS.free).messages
                          ? "Daily limit reached. Click to upgrade." 
                          : (selectedAttachment ? `Ask about this ${selectedAttachment.type}...` : "Message Trelvix AI...")
                        )
                      }
                      className="flex-1 bg-transparent border-none outline-none focus:ring-0 resize-none px-1 py-1.5 sm:py-2 text-base text-zinc-900 dark:text-zinc-50 placeholder:text-zinc-400 dark:placeholder:text-zinc-500 font-normal max-h-[120px] leading-relaxed min-w-0"
                    />
                  </div>

                  {/* Right container containing select and send button */}
                  <div className="flex items-center gap-1 sm:gap-2 shrink-0">
                    <ModelSelector 
                      selectedModelId={selectedModelId} 
                      userPlan={profile?.plan || 'free'} 
                      onSelectModel={handleSelectModel}
                      onUpgradeClick={() => setShowUpgradeModal(true)}
                      variant="compact"
                    />

                    {/* Action Button: Dynamic Live Mode / Send Button (Matches Image 1) */}
                    {(input.trim() || selectedAttachment) ? (
                      <button 
                        type="button"
                        onClick={() => sendMessage(activeTag ? `${activeTag} ${input}` : input)}
                        disabled={isLoading}
                        className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center transform active:scale-95 shrink-0 transition-all duration-200 bg-[#19C37D] hover:bg-[#15a86b] text-white shadow-md shadow-emerald-500/10"
                        title="Send message"
                      >
                        <ArrowUp className="w-4 h-4 stroke-[2.5]" />
                      </button>
                    ) : (
                      <button 
                        type="button"
                        onClick={() => {
                          playLiveOpenSound();
                          setShowLiveMode(true);
                        }}
                        className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center transform active:scale-95 shrink-0 transition-all duration-200 bg-[#19C37D] hover:bg-[#15a86b] text-white shadow-md shadow-emerald-500/20 cursor-pointer"
                        title="Start Live Mode"
                      >
                        <AudioLines className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.2]" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}



              <div className="flex items-center justify-center py-1">
                <p className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.15em] md:tracking-[0.2em] opacity-20 text-center">
                  Trelvix AI may provide inaccurate info. Verify important facts.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Modals */}
      <AnimatePresence>
        <LiveModeOverlay
          isOpen={showLiveMode}
          onClose={() => setShowLiveMode(false)}
          onSaveLiveSession={async (liveMsgs, liveSessionId, metadata = {}) => {
            if (!liveMsgs || liveMsgs.length === 0 || !user) return;

            // 1. Check idempotency: if this live session was already saved into a conversation, update it
            const existingConvId = liveSessionSavedConvMapRef.current.get(liveSessionId);
            if (existingConvId) {
              console.log(`[Live Mode Persistence] Updating existing conversation for liveSessionId: ${liveSessionId}`);
              await updateConversationMessages(existingConvId, liveMsgs);
              setConversations(prev => prev.map(c => c.id === existingConvId ? { ...c, messages: liveMsgs, updated_at: new Date().toISOString() } : c));
              setCurrentConversation(prev => (prev && prev.id === existingConvId) ? { ...prev, messages: liveMsgs, updated_at: new Date().toISOString() } : prev);
              setMessages(liveMsgs);
              setActiveView('chat');
              return;
            }

            // 2. If user already had an active conversation open before starting Live Mode, append to it
            if (currentConversation && currentConversation.id && messages.length > 0) {
              console.log(`[Live Mode Persistence] Appending live session messages to current conversation ${currentConversation.id}`);
              const existingMsgIds = new Set(messages.map(m => m.id));
              const freshMsgs = liveMsgs.filter(m => !existingMsgIds.has(m.id));
              const mergedMessages = [...messages, ...freshMsgs];

              await updateConversationMessages(currentConversation.id, mergedMessages);
              liveSessionSavedConvMapRef.current.set(liveSessionId, currentConversation.id);
              
              setConversations(prev => prev.map(c => c.id === currentConversation.id ? { ...c, messages: mergedMessages, updated_at: new Date().toISOString() } : c));
              setCurrentConversation(prev => prev ? { ...prev, messages: mergedMessages, updated_at: new Date().toISOString() } : null);
              setMessages(mergedMessages);
              setActiveView('chat');
              return;
            }

            // 3. Otherwise create a brand new conversation in history with an informative title
            const firstUserMsg = liveMsgs.find(m => m.role === 'user');
            const rawTitle = firstUserMsg?.content?.trim() || 'Voice Conversation';
            const title = rawTitle.length > 42 ? rawTitle.slice(0, 39) + '...' : rawTitle;

            const newConversation: any = {
              user_id: user.id,
              title: title,
              type: 'general',
              messages: liveMsgs,
              metadata: {
                source: 'live_mode',
                live_session_id: liveSessionId,
                ...metadata,
              },
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
              project_id: selectedProjectId || null,
            };

            try {
              const { data: savedConv, error } = await supabase
                .from('conversations')
                .insert(newConversation)
                .select()
                .single();

              if (error) {
                console.error('[Live Mode Persistence] Error saving new conversation to Supabase:', error);
                return;
              }

              if (savedConv) {
                liveSessionSavedConvMapRef.current.set(liveSessionId, savedConv.id);
                setCurrentConversation(savedConv);
                setMessages(liveMsgs);
                setConversations(prev => [savedConv, ...prev.filter(c => c.id !== savedConv.id)]);
                setActiveView('chat');
                if (typeof window !== 'undefined' && window.history) {
                  window.history.pushState({ conversationId: savedConv.id }, document.title, `/c/${savedConv.id}`);
                }
                console.log(`[Live Mode Persistence] Successfully saved live session ${liveSessionId} to conversation ${savedConv.id}`);
              }
            } catch (err) {
              console.error('[Live Mode Persistence] Unexpected error saving live conversation:', err);
            }
          }}
          getAuthToken={async () => {
            const { data: { session } } = await supabase.auth.getSession();
            return session?.access_token || null;
          }}
          userPlan={profile?.plan || 'free'}
        />

        {showSettings && (
          <Settings 
            profile={profile} 
            initialSection={typeof showSettings === 'string' ? (showSettings as any) : undefined}
            onSectionChange={(section) => setShowSettings(section as any)}
            onClose={() => setShowSettings(false)} 
            onUpdateProfile={updateProfile}
            onShowLegal={handleShowLegal}
            onUpgrade={() => {
              setUpgradeReason('manual');
              setShowUpgradeModal(true);
            }}
            isDarkMode={isDarkMode}
            onToggleTheme={() => setIsDarkMode(!isDarkMode)}
            imageSpeed={imageSpeed}
            onToggleImageSpeed={handleToggleImageSpeed}
          />
        )}
        {showSupportModal && (
          <SupportModal 
            profile={profile} 
            initialProblemTitle={supportInitialProblem}
            onClose={() => setShowSupportModal(false)} 
          />
        )}
        {showContextForm && (
          <ContextForm 
            type={showContextForm} 
            onSubmit={handleContextSubmit} 
            onCancel={() => setShowContextForm(null)} 
          />
        )}
        {showCreateProjectModal && (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm cursor-pointer animate-fade-in"
            onClick={() => setShowCreateProjectModal(false)}
          >
            <div 
              className="w-full max-w-md bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-xl p-6 cursor-default relative overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-lg font-bold text-zinc-900 dark:text-zinc-50 mb-4">Create Project</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-zinc-400 mb-1.5">Project Name</label>
                  <input 
                    type="text"
                    value={newProjectName}
                    onChange={(e) => setNewProjectName(e.target.value)}
                    placeholder="e.g. Website development"
                    className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-4 py-3 text-sm text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-zinc-400 mb-1.5">Optional Description</label>
                  <textarea 
                    value={newProjectDesc}
                    onChange={(e) => setNewProjectDesc(e.target.value)}
                    placeholder="Describe the scope of this project..."
                    rows={3}
                    className="w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-4 py-3 text-sm text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all resize-none"
                  />
                </div>
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button 
                    onClick={() => setShowCreateProjectModal(false)}
                    className="px-4 py-2 bg-zinc-100 dark:bg-zinc-900 hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleCreateProject}
                    disabled={!newProjectName.trim()}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all shadow-md hover:shadow-emerald-500/20 cursor-pointer"
                  >
                    Create
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        {conversationToMoveId && (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm cursor-pointer animate-fade-in"
            onClick={() => setConversationToMoveId(null)}
          >
            <div 
              className="w-full max-w-md bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-xl p-6 cursor-default relative overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-lg font-bold text-zinc-900 dark:text-zinc-50 mb-4">Choose Project</h3>
              <p className="text-xs text-zinc-500 mb-4">Select a workspace project to move this conversation into.</p>
              
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {/* No Project Option */}
                <button
                  onClick={() => setMoveTargetProjectId('none')}
                  className={cn(
                    "w-full text-left p-3.5 rounded-xl border text-sm flex items-center gap-3 transition-all cursor-pointer",
                    moveTargetProjectId === 'none'
                      ? "border-emerald-500/50 bg-emerald-500/5 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "border-zinc-100 dark:border-zinc-900 hover:bg-zinc-50 dark:hover:bg-zinc-900/50 text-zinc-700 dark:text-zinc-300"
                  )}
                >
                  <span className="text-base">🌐</span>
                  <span>Personal (No Project)</span>
                </button>

                {/* Project Options */}
                {projects.map((proj) => (
                  <button
                    key={`move-opt-${proj.id}`}
                    onClick={() => setMoveTargetProjectId(proj.id)}
                    className={cn(
                      "w-full text-left p-3.5 rounded-xl border text-sm flex items-center gap-3 transition-all cursor-pointer",
                      moveTargetProjectId === proj.id
                        ? "border-emerald-500/50 bg-emerald-500/5 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold"
                        : "border-zinc-100 dark:border-zinc-900 hover:bg-zinc-50 dark:hover:bg-zinc-900/50 text-zinc-700 dark:text-zinc-300"
                    )}
                  >
                    <span className="text-base">📁</span>
                    <span>{proj.title}</span>
                  </button>
                ))}
              </div>

              <div className="flex items-center justify-end gap-3 pt-6 border-t border-zinc-100 dark:border-zinc-900 mt-4">
                <button 
                  onClick={() => setConversationToMoveId(null)}
                  className="px-4 py-2 bg-zinc-100 dark:bg-zinc-900 hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleMoveConversation}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all shadow-md hover:shadow-emerald-500/20 cursor-pointer"
                >
                  Move
                </button>
              </div>
            </div>
          </div>
        )}
        {showLegal && (
          <LegalModal 
            type={showLegal} 
            onClose={handleCloseLegal} 
          />
        )}
        {inviteToken && (
          <AcceptInvitationView
            token={inviteToken}
            onComplete={() => {
              setInviteToken(null);
              window.history.replaceState({}, document.title, window.location.pathname);
            }}
          />
        )}
        <UpgradeModal 
          isOpen={showUpgradeModal} 
          onClose={() => setShowUpgradeModal(false)} 
          reason={upgradeReason}
          profile={profile}
        />
        {showTempChatIntro && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="bg-white dark:bg-[#1E1F22] text-zinc-800 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-800/80 rounded-3xl max-w-sm md:max-w-md w-full p-6 md:p-8 shadow-2xl relative overflow-hidden"
            >
              <h3 className="text-xl font-bold tracking-tight mb-6 text-zinc-900 dark:text-white select-none">
                Temporary Chat
              </h3>
              
              <div className="space-y-6 mb-8 select-none">
                {/* Item 1 */}
                <div className="flex items-start gap-4">
                  <div className="mt-1 w-6 h-6 flex items-center justify-center shrink-0 text-zinc-400 dark:text-zinc-500">
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="3.5 2">
                      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-zinc-800 dark:text-zinc-200">Not in history</h4>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed mt-1">
                      Temporary chats won't appear in your history. For safety purposes, we may keep a copy of this chat for up to 30 days.
                    </p>
                  </div>
                </div>

                {/* Item 2 */}
                <div className="flex items-start gap-4">
                  <div className="mt-1.5 w-6 h-6 flex items-center justify-center text-zinc-400 dark:text-zinc-500 font-mono text-xs font-black shrink-0 tracking-tighter select-none">
                    0\0
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-zinc-800 dark:text-zinc-200">No model training</h4>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed mt-1">
                      Temporary chats won't be used to improve our models.
                    </p>
                  </div>
                </div>

                {/* Item 3 */}
                <div className="flex items-start gap-4">
                  <div className="mt-1 w-6 h-6 flex items-center justify-center shrink-0 text-zinc-400 dark:text-zinc-500">
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                      <polyline points="14 2 14 8 20 8" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-zinc-800 dark:text-zinc-200">Memory off</h4>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed mt-1">
                      While in a temporary chat, Trelvix AI won't use or update its memory. Custom instructions will still be followed if you have them enabled.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3 border-t border-zinc-200 dark:border-zinc-800/40 pt-4">
                <button 
                  type="button"
                  onClick={() => setShowTempChatIntro(false)}
                  className="px-4 py-2 text-xs font-bold text-zinc-450 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="button"
                  onClick={() => {
                    setIsTemporaryChat(true);
                    handleNewChat();
                    setShowTempChatIntro(false);
                    toast.success("Temporary chat is ON");
                  }}
                  className="px-6 py-2 bg-zinc-950 dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-950 text-xs font-bold uppercase tracking-widest rounded-full transition-all active:scale-95 cursor-pointer"
                >
                  Continue
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Image Lightbox */}
      <AnimatePresence>
        {expandedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setExpandedImage(null)}
            className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-xl flex flex-col items-center justify-between p-4 md:p-6"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-5xl h-full flex flex-col items-center justify-between py-2 sm:py-4"
            >
              {/* Top Bar Controls */}
              <div className="w-full flex items-center justify-between z-10 gap-4 select-none mb-3 sm:mb-4 shrink-0">
                <div className="bg-black/60 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 max-w-[55%] sm:max-w-md shadow-md">
                  <p className="text-white text-xs sm:text-sm font-semibold truncate">{expandedImage.title || 'Generated Artwork'}</p>
                </div>

                <div className="flex items-center gap-2">
                  {/* Download Icon Button with 360 Loader */}
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      
                      // Convert user creation prompt/title to a clean, descriptive file slug
                      const cleanSlug = expandedImage.title
                        ? expandedImage.title
                            .trim()
                            .toLowerCase()
                            .slice(0, 80) // Keep file name inside standard length limits
                            .replace(/[^a-z0-9\s-]/g, '') // remove weird symbols
                            .replace(/\s+/g, '-') // convert spaces into clean dashes
                            .replace(/-+/g, '-') // prevent double dashes
                        : 'trelvix-ai-image';
                      
                      const computedFilename = cleanSlug || 'trelvix-ai-image';
                      handleDownloadImage(expandedImage.url, `${computedFilename}.png`);
                    }}
                    disabled={isDownloading}
                    className="flex items-center justify-center w-10 h-10 bg-white/10 hover:bg-white/20 active:scale-95 focus:outline-none disabled:pointer-events-none rounded-full text-white transition-all shadow-lg border border-white/10 relative"
                    title="Download High Res"
                  >
                    {isDownloading ? (
                      <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                    ) : (
                      <Download className="w-5 h-5" />
                    )}
                  </button>

                  {/* Share Icon Button */}
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      handleShareMessage({ content: expandedImage.title, image_url: expandedImage.url, role: 'assistant', id: 'img-share' } as any);
                    }}
                    className="flex items-center justify-center w-10 h-10 bg-white/10 hover:bg-white/20 active:scale-95 focus:outline-none rounded-full text-white transition-all shadow-lg border border-white/10"
                    title="Share Artwork"
                  >
                    <ExternalLink className="w-5 h-5" />
                  </button>

                  {/* Close Icon Button */}
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setExpandedImage(null);
                    }}
                    className="flex items-center justify-center w-10 h-10 bg-white/10 hover:bg-white/20 active:scale-95 focus:outline-none rounded-full text-white transition-all shadow-lg border border-white/10"
                    title="Close"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Main Image Viewport supporting interactive drag, scroll wheel, and touch pinch zoom */}
              <div 
                className="relative w-full flex-1 min-h-0 flex items-center justify-center bg-zinc-950/40 rounded-3xl border border-white/5 overflow-hidden select-none"
                onWheel={handleImageWheel}
                onMouseDown={handleImageMouseDown}
                onMouseMove={handleImageMouseMove}
                onMouseUp={handleImageMouseUpOrLeave}
                onMouseLeave={handleImageMouseUpOrLeave}
                onTouchStart={handleImageTouchStart}
                onTouchMove={handleImageTouchMove}
                onTouchEnd={handleImageTouchEnd}
              >
                <div 
                  className="w-full h-full flex items-center justify-center pointer-events-none"
                  style={{
                    transform: `translate3d(${zoomPosition.x}px, ${zoomPosition.y}px, 0) scale(${zoomScale})`,
                    transition: isDraggingImage ? 'none' : 'transform 0.15s ease-out',
                    transformOrigin: 'center center'
                  }}
                >
                  <ImageWithLoader 
                    src={expandedImage.url} 
                    alt={expandedImage.title} 
                    skipWatermark={profile?.plan === 'pro' || profile?.plan === 'plus'}
                    className="max-h-[75vh] md:max-h-[82vh] max-w-full w-auto h-auto object-contain select-none pointer-events-none shadow-2xl rounded-2xl border border-white/5"
                  />
                </div>

                {/* Ambient dynamic controls directly overlayed on the image viewport */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/70 backdrop-blur-md px-4 py-2.5 rounded-full border border-white/10 flex items-center gap-4 shadow-lg pointer-events-auto">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setZoomScale(prev => {
                        const next = Math.max(prev - 0.25, 0.5);
                        if (next <= 1.01) setZoomPosition({ x: 0, y: 0 });
                        return next;
                      });
                    }}
                    className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/25 active:scale-90 text-white flex items-center justify-center transition-all"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>

                  <span className="text-white text-xs font-mono font-medium tracking-wide min-w-[3rem] text-center select-none">
                    {Math.round(zoomScale * 100)}%
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setZoomScale(prev => Math.min(prev + 0.25, 6.0));
                    }}
                    className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/25 active:scale-90 text-white flex items-center justify-center transition-all"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>

                  <div className="w-px h-4 bg-white/10" />

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setZoomScale(1);
                      setZoomPosition({ x: 0, y: 0 });
                    }}
                    className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/25 active:scale-90 text-white flex items-center justify-center transition-all"
                    title="Reset Zoom"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Light Subtitle Action Instruction Indicator */}
              <div className="mt-2 shrink-0 select-none text-[10px] text-white/30 font-semibold tracking-wider uppercase border-t border-white/5 pt-2 w-full text-center">
                <span>Pinch to zoom, scroll wheel to scale, or drag to pan around</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Custom Delete Confirmation Modal */}
      <AnimatePresence>
        {deleteConfirmId && (() => {
          const conversationToConfirm = conversations.find(c => c.id === deleteConfirmId);
          return (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeleteConfirmId(null)}
              className="fixed inset-0 z-[110] bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ scale: 0.95, y: 15, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                exit={{ scale: 0.95, y: 15, opacity: 0 }}
                transition={{ type: "spring", duration: 0.4 }}
                onClick={(e) => e.stopPropagation()}
                className="w-full max-w-md bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl shadow-2xl p-6 md:p-8 flex flex-col gap-6"
              >
                {/* Header */}
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-red-100 dark:bg-red-950/40 text-red-600 dark:text-red-400 rounded-2xl flex items-center justify-center shrink-0">
                    <Trash2 className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="text-xl font-bold text-zinc-900 dark:text-zinc-50">Delete Conversation?</h3>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">
                      This action is permanent and cannot be undone. All messages and assets inside this chat will be lost.
                    </p>
                  </div>
                </div>

                {/* Conversation Details Box if title exists */}
                {conversationToConfirm && (
                  <div className="p-4 bg-zinc-50 dark:bg-zinc-950/40 border border-zinc-100 dark:border-zinc-800/80 rounded-2xl">
                    <span className="text-[11px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider block mb-1">Target Chat</span>
                    <span className="text-sm font-semibold text-zinc-800 dark:text-zinc-200 line-clamp-2">
                      {conversationToConfirm.title || 'Untitled Session'}
                    </span>
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setDeleteConfirmId(null)}
                    className="flex-1 py-3.5 px-4 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 font-bold rounded-2xl transition-colors text-sm"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={confirmDeleteConversation}
                    className="flex-1 py-3.5 px-4 bg-red-600 hover:bg-red-700 text-white font-bold rounded-2xl transition-colors text-sm shadow-lg shadow-red-600/10 dark:shadow-red-900/10"
                  >
                    Delete Chat
                  </button>
                </div>
              </motion.div>
            </motion.div>
          );
        })()}
      </AnimatePresence>

      {showProjectSettingsModal && selectedProjectId && projects.some(p => p.id === selectedProjectId) && (
        <ProjectSettingsModal 
          isOpen={showProjectSettingsModal}
          onClose={() => setShowProjectSettingsModal(false)}
          project={projects.find(p => p.id === selectedProjectId)!}
          onSave={handleUpdateProjectSettings}
        />
      )}

      <Toaster 
        position="top-center" 
        theme={isDarkMode ? 'dark' : 'light'} 
        toastOptions={{
          style: {
            background: isDarkMode ? '#09090b' : 'white',
            color: isDarkMode ? '#f4f4f5' : '#18181b',
            border: `1px solid ${isDarkMode ? '#27272a' : '#e4e4e7'}`,
            borderRadius: '12px',
            fontSize: '13px',
            fontWeight: '600',
            boxShadow: isDarkMode ? '0 10px 30px -10px rgba(0,0,0,0.5)' : '0 10px 30px -10px rgba(0,0,0,0.1)'
          }
        }}
      />
    </div>
  </OrganizationProvider>
);
}
