import React, { useRef, useEffect } from 'react';
import { 
  Plus, 
  Image as ImageIcon, 
  FileText, 
  Globe, 
  ArrowUp,
  X,
  Film,
  Edit3,
  Mic,
  AudioLines
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ModelSelector from './ModelSelector';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface WelcomeScreenProps {
  input: string;
  setInput: (value: string) => void;
  sendMessage: (value?: string) => void;
  selectedModelId: string;
  onSelectModel: (modelId: string) => void;
  userPlan: 'free' | 'plus' | 'pro';
  onUpgradeClick: () => void;
  onUploadClick: () => void;
  selectedAttachment: any;
  clearAttachment: () => void;
  isLoading: boolean;
  textareaRef: React.RefObject<HTMLTextAreaElement>;
  isTemporaryChat?: boolean;
  activeTag: string | null;
  setActiveTag: (tag: string | null) => void;
  handleInputChange: (value: string) => void;
  onStartLiveMode?: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  input,
  setInput,
  sendMessage,
  selectedModelId,
  onSelectModel,
  userPlan,
  onUpgradeClick,
  onUploadClick,
  selectedAttachment,
  clearAttachment,
  isLoading,
  textareaRef,
  isTemporaryChat = false,
  activeTag,
  setActiveTag,
  handleInputChange,
  onStartLiveMode,
}) => {

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Backspace' && textareaRef.current && textareaRef.current.selectionStart === 0 && textareaRef.current.selectionEnd === 0 && activeTag) {
      e.preventDefault();
      setActiveTag(null);
    } else if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(activeTag ? `${activeTag} ${input}` : input);
    }
  };

  // Adjust input box height dynamically
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [input, textareaRef]);

  const handleActionClick = (actionType: 'image' | 'write' | 'search') => {
    let tag = '';
    if (actionType === 'image') tag = '@Image';
    if (actionType === 'write') tag = '@Write';
    if (actionType === 'search') tag = '@WebSearch';

    if (activeTag === tag) {
      return;
    }

    setActiveTag(tag);
    setTimeout(() => {
      textareaRef.current?.focus();
    }, 100);
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-end p-4 sm:p-6 md:p-8 w-full max-w-3xl mx-auto animate-fade-in min-h-0 h-full">
      
      {/* Container that dynamically swaps layout order on mobile vs desktop */}
      <div className="w-full flex-1 flex flex-col justify-end gap-3 sm:gap-4 max-w-2xl relative z-30 min-h-0">
        
        {/* Scrollable Top Section */}
        <div className="flex-1 w-full flex flex-col justify-end gap-3 sm:gap-4 overflow-y-auto scrollbar-hide py-2 min-h-0">
          {isTemporaryChat ? (
            <div className="text-center mb-2 animate-fade-in shrink-0">
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-semibold tracking-tight text-zinc-900 dark:text-zinc-50 mb-3 font-sans">
                Temporary Chat
              </h1>
              <p className="text-xs md:text-sm text-zinc-500 dark:text-zinc-400 leading-relaxed max-w-xl mx-auto font-normal">
                This chat won't appear in history or be used to train our models. For safety purposes, we may keep a copy of this chat for up to 30 days.
              </p>
            </div>
          ) : (
            /* Title Header (Hidden on Mobile, Visible on Desktop with responsive size) */
            <h1 className="hidden sm:block text-2xl sm:text-3xl md:text-4xl font-semibold tracking-tight text-center text-zinc-900 dark:text-zinc-50 mb-1 sm:mb-2 font-sans shrink-0">
              Where should we begin?
            </h1>
          )}

          {/* Quick Actions List (Stacked vertically, left-aligned, matching style perfectly) - ABOVE prompt bar */}
          <div className="w-full flex flex-col gap-1 pl-1 shrink-0">
            
            {/* Card 1: Write or edit */}
            <button
              onClick={() => handleActionClick('write')}
              className="flex items-center gap-4 text-left text-zinc-700 dark:text-zinc-200 hover:text-zinc-900 dark:hover:text-zinc-50 hover:bg-zinc-100/50 dark:hover:bg-zinc-800/40 border border-transparent px-3 py-2.5 sm:py-2 rounded-2xl transition-all duration-200 select-none group w-full"
            >
              <div className="w-6 h-6 flex items-center justify-center shrink-0">
                <Edit3 className="w-5.5 h-5.5 text-[#19C37D] dark:text-[#19C37D] group-hover:scale-105 transition-transform" />
              </div>
              <span className="text-[15px] sm:text-base font-semibold tracking-tight">Write or edit</span>
            </button>

            {/* Card 2: Create an image */}
            <button
              onClick={() => handleActionClick('image')}
              className="flex items-center gap-4 text-left text-zinc-700 dark:text-zinc-200 hover:text-zinc-900 dark:hover:text-zinc-50 hover:bg-zinc-100/50 dark:hover:bg-zinc-800/40 border border-transparent px-3 py-2.5 sm:py-2 rounded-2xl transition-all duration-200 select-none group w-full"
            >
              <div className="w-6 h-6 flex items-center justify-center shrink-0">
                <ImageIcon className="w-5.5 h-5.5 text-[#19C37D] dark:text-[#19C37D] group-hover:scale-105 transition-transform" />
              </div>
              <span className="text-[15px] sm:text-base font-semibold tracking-tight">Create an image</span>
            </button>

            {/* Card 3: Look something up */}
            <button
              onClick={() => handleActionClick('search')}
              className="flex items-center gap-4 text-left text-zinc-700 dark:text-zinc-200 hover:text-zinc-900 dark:hover:text-zinc-50 hover:bg-zinc-100/50 dark:hover:bg-zinc-800/40 border border-transparent px-3 py-2.5 sm:py-2 rounded-2xl transition-all duration-200 select-none group w-full"
            >
              <div className="w-6 h-6 flex items-center justify-center shrink-0">
                <Globe className="w-5.5 h-5.5 text-[#19C37D] dark:text-[#19C37D] group-hover:scale-105 transition-transform" />
              </div>
              <span className="text-[15px] sm:text-base font-semibold tracking-tight">Look something up</span>
            </button>
          </div>
        </div>

        {/* Prompt Input Bar (Desktop or Mobile) */}
        <div className="w-full shrink-0 mt-auto">
          {/* Attachment preview inside the input container frame */}
          <AnimatePresence>
            {selectedAttachment && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="mb-3 p-2 bg-zinc-100/80 dark:bg-zinc-800/50 rounded-2xl border border-zinc-200/50 dark:border-zinc-700/50 flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5 overflow-hidden">
                  <div className="w-12 h-10 rounded-xl overflow-hidden bg-white dark:bg-zinc-850 flex items-center justify-center border border-zinc-200/60 dark:border-zinc-700/60 shadow-xs shrink-0">
                    {selectedAttachment.type === 'image' ? (
                      <img src={selectedAttachment.preview} alt="Attachment" className="w-full h-full object-cover" />
                    ) : (
                      <div className="text-zinc-400">
                        {selectedAttachment.type === 'video' ? <Film className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
                      </div>
                    )}
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200 truncate max-w-[150px]">
                      {selectedAttachment.file.name}
                    </span>
                    <span className="text-[10px] text-zinc-400 uppercase tracking-widest font-black">
                      {selectedAttachment.type}
                    </span>
                  </div>
                </div>
                <button 
                  onClick={clearAttachment}
                  className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 rounded-full transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Fully compliant styled pill matching images exactly (Single-row layout) */}
          <div className="bg-zinc-100 dark:bg-[#1E1F22] border border-zinc-200/40 dark:border-zinc-800/60 rounded-full shadow-lg focus-within:ring-2 focus-within:ring-zinc-900/5 dark:focus-within:ring-white/5 dark:focus-within:border-zinc-700 transition-all flex items-center px-2 sm:px-3 py-1.5 min-h-[48px] sm:min-h-[52px] relative overflow-visible">
            
            {/* Left Plus button (visible on both mobile and desktop) */}
            <button 
              type="button"
              onClick={onUploadClick}
              className="p-2 text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200 rounded-full hover:bg-zinc-200/50 dark:hover:bg-zinc-800/50 transition-colors shrink-0"
              title="Upload file or attachment"
            >
              <Plus className="w-5 h-5 font-bold" />
            </button>

            {/* Middle Container: Tag Pill and Textarea */}
            <div className="flex-1 flex items-center gap-1.5 sm:gap-2 min-w-0">
              {activeTag && (
                <div className="flex items-center gap-1 bg-zinc-200 dark:bg-zinc-800 border border-zinc-300/40 dark:border-zinc-700/40 text-zinc-800 dark:text-zinc-200 px-2.5 py-1 rounded-full text-xs font-semibold select-none shrink-0 animate-fade-in">
                  {activeTag === '@Image' && <ImageIcon className="w-3.5 h-3.5 text-zinc-500 dark:text-zinc-400" />}
                  {activeTag === '@Write' && <Edit3 className="w-3.5 h-3.5 text-zinc-500 dark:text-zinc-400" />}
                  {activeTag === '@WebSearch' && <Globe className="w-3.5 h-3.5 text-zinc-500 dark:text-zinc-400" />}
                  <span>{activeTag}</span>
                  <button 
                    type="button"
                    onClick={() => setActiveTag(null)}
                    className="p-0.5 hover:bg-zinc-300 dark:hover:bg-zinc-700 rounded-full transition-colors ml-0.5"
                  >
                    <X className="w-3 h-3 text-zinc-500 dark:text-zinc-400" />
                  </button>
                </div>
              )}

              {/* Textarea */}
              <textarea
                ref={textareaRef}
                rows={1}
                value={input}
                onChange={(e) => handleInputChange(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={activeTag ? "" : "Ask anything"}
                className="flex-1 bg-transparent border-none outline-none focus:ring-0 resize-none px-1 py-1.5 sm:py-2 text-base text-zinc-900 dark:text-zinc-50 placeholder:text-zinc-400 dark:placeholder:text-zinc-500 font-normal max-h-[120px] leading-relaxed min-w-0"
              />
            </div>

            {/* Right container containing model selector and dynamic action button */}
            <div className="flex items-center gap-1 sm:gap-2 shrink-0">
              <ModelSelector 
                selectedModelId={selectedModelId} 
                userPlan={userPlan} 
                onSelectModel={onSelectModel}
                onUpgradeClick={onUpgradeClick}
                variant="compact"
              />

              {/* Action Button: Changes dynamically between Live Mode and Send button (Matches Image 1) */}
              {(input.trim() || selectedAttachment) ? (
                <button 
                  type="button"
                  onClick={() => sendMessage(activeTag ? `${activeTag} ${input}` : input)}
                  disabled={isLoading}
                  className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center transform active:scale-95 shrink-0 transition-all duration-200 bg-[#19C37D] hover:bg-[#15a86b] text-white shadow-md shadow-emerald-500/10"
                  title="Send message"
                >
                  <ArrowUp className="w-4 h-4 stroke-[2.5]" />
                </button>
              ) : (
                <button 
                  type="button"
                  onClick={onStartLiveMode}
                  className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center transform active:scale-95 shrink-0 transition-all duration-200 bg-[#19C37D] hover:bg-[#15a86b] text-white shadow-md shadow-emerald-500/20 cursor-pointer"
                  title="Start Live Mode"
                >
                  <AudioLines className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.2]" />
                </button>
              )}
            </div>
          </div>
        </div>

      </div>
      
      {isTemporaryChat && (
        <div className="mt-4 text-[10px] sm:text-xs text-zinc-400 dark:text-zinc-600 font-normal tracking-wide text-center shrink-0">
          For safety, we may keep a copy of this chat for up to 30 days.
        </div>
      )}
    </div>
  );
};
